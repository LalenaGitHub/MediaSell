package mediasell.model;

import java.util.ArrayList;

import mediasell.util.UtilMS;

public class Artikelliste2 {
	
	public static ArrayList<Artikel> artikelListe; // Eine ArrayListe, die alle Artikel beinhalt 
	
	private static UtilMS util = new UtilMS (); // Objekt f�r die Arbeit mit Utiliten 
	
	/**
	 * Methode suche Objekt Artikel mit vogegebenen artikelNr in der
	 * artikelListe
	 * 
	 * @param artikelNr
	 * @return Objekt Artikel
	 */
	public static Artikel getArtikelFromListe(int artikelNr) {
		// artikelListe in der losale Liste kopieren
		ArrayList<Artikel> alleArtikelListe = getArtikelListe();

		Artikel result = null;

		for (Artikel artikel : alleArtikelListe) {
			if (artikel.getArtikelNr() == artikelNr) {
				result = artikel;
			}
		}
		return result;
	}
	
	/**
	 * Methode makeArtikelListe Eine artikelListe mit Objekten Artikel wird mit
	 * Hilfe von artikelListeString gef�llt
	 * 
	 * @param artikelListeString
	 * @return alleArtikelListe ArrayList<Artikel>
	 */
	public static ArrayList<Artikel> makeArtikelListe(ArrayList<String[]> artikelListeString) {

		int artikelNr;
		String author;
		String titel;
		double preis;
		boolean status = false;
		int bestand;
		int warengruppe;

		ArrayList<Artikel> alleArtikelListe = new ArrayList<>();

		// StringListe durchsuchen
		for (String[] list : artikelListeString) {
			artikelNr = Integer.parseInt(list[0]);
			author = list[1];
			titel = list[2];
			preis = Double.parseDouble(list[3]);
			status = util.getStatus(list[4]);
			bestand = Integer.parseInt(list[5]);
			warengruppe = Integer.parseInt(list[6]);

			// Objekt Artikel erstellen
			Artikel artikel = new Artikel(artikelNr, author, titel, preis, status, bestand, warengruppe);
			// artikel in der Liste einf�gen
			alleArtikelListe.add(artikel);
		}

		return alleArtikelListe;
	}
	
	/**
	 * Getter-Methode
	 * 
	 * @return al ArrayList<Artikel> ArtikelListe
	 */
	public static ArrayList<Artikel> getArtikelListe() {
		ArrayList<Artikel> al = artikelListe;
		return al;
	}

	/**
	 * Methode sucht alle Artikel in der DB nach einem Suchwort
	 * 
	 * @param suchWort
	 * @return Liste von Artikel
	 */
	public static ArrayList<Artikel> sucheArtikel(String suchWort) {

		ArrayList<Artikel> listGefundenArtikel = new ArrayList<Artikel>();

		for (Artikel artikel : artikelListe) {
			if (String.valueOf(artikel.getArtikelNr()).contains(suchWort)) {
				listGefundenArtikel.add(artikel);
			}
		}

		return listGefundenArtikel;
	}

}
