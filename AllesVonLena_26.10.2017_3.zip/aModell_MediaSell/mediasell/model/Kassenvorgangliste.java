package mediasell.model;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import mediasell.util.UtilMS;

public class Kassenvorgangliste {

	public static ObservableList<Rechnung> kassenvorgangListe = FXCollections.observableArrayList();
	static UtilMS util = new UtilMS(); // Objekt f�r die Arbeit mit Utiliten

	// Festlegung des Formats:
	static SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
	
	// View vKKA
		/**
		 * Methode bildet eine Liste mit Objekten Rechnung aus der StringListe
		 * 
		 * @param kassenvorgangListeString
		 * @return ArrayList mit Objekten Rechnung
		 */
		public static ObservableList<Rechnung> makeKassenvorgangListe(
				ArrayList<String[]> kassenvorgangListeString) {
			// Kassenvorgang-Daten
			int kassenvorgangID;
			String datumString;
			boolean storno;
			// Kunde-Daten
			int kundeNr;
			String vorname;
			String nachname;
			String strasse;
			String hausnr;
			String plz;
			String stadt;
			String email;
			String telefonNr;
			int zahlungsart;
			boolean statusKunde;

			Date datum = new Date();
			datumString = dateFormat.format(datum);

			ObservableList<Position> gesamteBestellung = FXCollections.observableArrayList();

			int alteKassenvorgangID = -1;  

			for (String[] list : kassenvorgangListeString) {
				// Kassenvorgang-Daten
				kassenvorgangID = Integer.parseInt(list[0]);
				datumString = (list[1]);
				storno = util.getStatus(list[2]);
				// Kunde-Daten
				kundeNr = Integer.parseInt(list[11]);
				vorname = (list[12]);
				nachname = (list[13]);
				strasse = (list[14]);
				hausnr = (list[15]);
				plz = (list[16]);
				stadt = (list[17]);
				email = (list[18]);
				telefonNr = (list[19]);
				zahlungsart = Integer.parseInt(list[20]);
				statusKunde = util.getStatus(list[21]);

				gesamteBestellung = makeGesamteBestellungZurKassenvorgangID(kassenvorgangListeString, kassenvorgangID);
				
				Kunde kunde = new Kunde(kundeNr, vorname, nachname, strasse, hausnr, plz,
						stadt, email, telefonNr, zahlungsart, statusKunde);
				
				// Neue Rechnung rechnung ohne gesamteBestellung
				Rechnung rechnung  = new Rechnung(gesamteBestellung, kassenvorgangID, datumString, storno,
						kunde.getKundeNr());

				if (!(kassenvorgangID == alteKassenvorgangID)) {
				kassenvorgangListe.add(rechnung);
				gesamteBestellung = FXCollections.observableArrayList();
				}
				 

				alteKassenvorgangID = kassenvorgangID;
				System.out.println("alteKassenvorgangID :" + alteKassenvorgangID);

			}


			return kassenvorgangListe;
		}

	
		private static ObservableList<Position> makeGesamteBestellungZurKassenvorgangID(
				ArrayList<String[]> kassenvorgangListeString, int gesuchteKassenvorgangId) {
			// Kassenvorgang-Daten
			int kassenvorgangID;

			// Artikel-Daten
			int artikelNr;
			int anzahl;
			String author;
			String titel;
			double preis;
			boolean statusArtikel;
			int bestand;
			int warengruppe;
		 
					
			ObservableList<Position>  gesamteBestellung = FXCollections.observableArrayList();
			for (String[] list : kassenvorgangListeString) {
				// Kassenvorgang-Daten
				kassenvorgangID = Integer.parseInt(list[0]);
	 
				// Artikel-Daten
				artikelNr = Integer.parseInt(list[3]); //
				anzahl = Integer.parseInt(list[4]); //
				author = (list[5]);//
				titel = (list[6]);//
				preis = Double.parseDouble(list[7]);//
				statusArtikel = util.getStatus(list[8]); 
				bestand = Integer.parseInt(list[9]);
				warengruppe = Integer.parseInt(list[10]);
				
				
				if (kassenvorgangID == gesuchteKassenvorgangId) {
				// Position mit Artikel und Anzahl
				Artikel artikel = new Artikel(artikelNr, author, titel, preis,
						statusArtikel, bestand, warengruppe);
				
				Position p = new Position(kassenvorgangID, artikel, anzahl);
				
			    gesamteBestellung.add(p);
				}
			}
			
			return gesamteBestellung;
		}		
		
		
	
	/**
	 * Methode sucht die DB nach kunden Vorname, Nachname, Datum ducrch
	 * 
	 * @param suchWort
	 * @return Liste von Rechnungen
	 */
	public ArrayList<Rechnung> rechnungSuchen(String suchWort) {

		ArrayList<Rechnung> listGefundenRechnungen = new ArrayList<Rechnung>();

		for (Rechnung rechnung : kassenvorgangListe) {
			// System.out.println(rechnung.toString());

		 

			if (String.valueOf(rechnung.getKassenvorgangID())
					.contains(suchWort)) {
				listGefundenRechnungen.add(rechnung);
			} else if ((rechnung.getDatum().contains(suchWort))) {
				listGefundenRechnungen.add(rechnung);

			} else if (Kundeliste.getKundeFromListe(rechnung.getKundeNr())
					.getNachname().contains(suchWort)) {
				listGefundenRechnungen.add(rechnung);
			} else if (Kundeliste.getKundeFromListe(rechnung.getKundeNr())
					.getVorname().contains(suchWort)) {
				listGefundenRechnungen.add(rechnung);
			}

			// Suche nach Artikel
			// TODO zu komliziert

		}

		return listGefundenRechnungen;
	}
	
}
