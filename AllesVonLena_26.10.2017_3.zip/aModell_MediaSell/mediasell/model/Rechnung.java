package mediasell.model;


import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Rechnung {

	private ObservableList<Position> gesamteBestellung = FXCollections.observableArrayList();

	private IntegerProperty kassenvorgangID;
	private StringProperty datum;
	private BooleanProperty storno;
	private IntegerProperty kundeNr;

	
	/**
	 * Konstruktor
	 */
	private Rechnung () {
		ObservableList<Position> list = FXCollections.observableArrayList();
		
		this.gesamteBestellung  =  list;
		this.kassenvorgangID = new SimpleIntegerProperty();
		this.datum = new SimpleStringProperty();
		this.storno = new SimpleBooleanProperty();
		this.kundeNr = new SimpleIntegerProperty();

		setGesamteBestellung(list);
        setKassenvorgangID(0);		
	    setDatum("");
	    setStorno(false);
	    setKundeNr(0);
	}
	

	/** Konstruktor 
	 * @param gesamteBestellungs
	 * @param rechnungId
	 * @param datum
	 * @param storno
	 * @param kundeNr
	 */
	public Rechnung(ObservableList<Position> gesamteBestellung, int kassenvorgangID, String datum, boolean storno, int kundeNr) {
		
		this();
		setGesamteBestellung(gesamteBestellung);
        setKassenvorgangID(kassenvorgangID);		
	    setDatum(datum);
	    setStorno(storno);
	    setKundeNr(kundeNr);
	}
	
	/** Konstruktor ohne Position-Liste
	 * @param rechnungId
	 * @param datum
	 * @param storno
	 * @param kundeNr
	 */
	public Rechnung( int kassenvorgangID, String datum, boolean storno, int kundeNr) {
		
		this();
		
		ObservableList<Position> list = FXCollections.observableArrayList();
		setGesamteBestellung(list);
        setKassenvorgangID(kassenvorgangID);		
	    setDatum(datum);
	    setStorno(storno);
	    setKundeNr(kundeNr);
 
	}
	
	private void setKundeNr(int kundeNr) {
		this.kundeNr.set(kundeNr);
		
	}


	private void setStorno(boolean storno) {
		this.storno.set(storno);
		
	}


	private void setDatum(String datum) {
	this.datum.set(datum);
		
	}


	private void setKassenvorgangID(int kassenvorgangID) {
 		
		this.kassenvorgangID.set(kassenvorgangID);
		 
		
	}


	private void setGesamteBestellung(ObservableList<Position> gesamteBestellung) {
		
		// TODO nicht fertig
//	this.gesamteBestellung.set(gesamteBestellung);
		
	}


	// "Die Rechnungsausgabedateien werden nach
	// Kassenvorgangsnummer_Kundennachname benannt


	public String toString() {
		String rechnungString = 
				"\n------------------------------------------------------------------\n "
				+ "Rechnung Nr. " + getKassenvorgangID() 
				+ "_" + getKunde(getKundeNr()).getNachname() 
				+ " \t\t" + getDatum() 
				+ "\n------------------------------------------------------------------"
				+ "\n";

		for (Position  p : gesamteBestellung) {
			 
			rechnungString = rechnungString + p.toString() + "\n";
			 
		}
		
		if (getStorno()) {
			rechnungString = rechnungString + "\n" + " STORIERT ";
		}
		
		return rechnungString;

	}

	
	
	public int getAnzahlPositionen() {
		int count = 0;
		for (Position  p : gesamteBestellung) {
			count++;
		}
		System.out.println("Anz. Position" + count);
		return count;
		
	}


	//------------------------Getter/Setter--------------------------//
	private Kunde getKunde(int kundeNr) {
		Kunde kunde = Kundeliste.getKundeFromListe(kundeNr);
		return kunde;
	}

	public boolean getStorno() {
		return storno.getValue();
		 
	}
	
	public int getKundeNr() {
		return kundeNr.getValue();
	}

	public int getKassenvorgangID() {
		return kassenvorgangID.getValue();
	}

	public String getDatum() {
		return datum.getValue();
	}


	public ObservableList<Position> getGesamteBestellung() {
		 
		return gesamteBestellung;
	}

	// -------------------------------------------------------------------//

}
