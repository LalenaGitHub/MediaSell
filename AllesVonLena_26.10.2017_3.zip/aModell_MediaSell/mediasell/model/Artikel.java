package mediasell.model;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 * @author Gruppe WW
 *
 */

public class Artikel {
	/**
	 * Artikel parameter
	 */

	private IntegerProperty artikelNr; // Artikel-Nr.
	private StringProperty autor; // Artikel-Autor
	private StringProperty titel; // Artikel-Titel
	private DoubleProperty preis; // Artikel - Preis
	private BooleanProperty status; // Artikel-Status: Aktiv (true), Inaktiv (False)
	private IntegerProperty bestand; // Artikel-Bestand: die vorhandene Menge
	private IntegerProperty warengruppe; // Artikel-Warengruppe: 1-CDs, 2-Buch

	/**
	 * Konstruktor
	 */
	private Artikel() {
		this.artikelNr = new SimpleIntegerProperty();
		this.autor = new SimpleStringProperty();
		this.titel = new SimpleStringProperty();
		this.preis = new SimpleDoubleProperty();
		this.status = new SimpleBooleanProperty();
		this.bestand = new SimpleIntegerProperty();
		this.warengruppe = new SimpleIntegerProperty();

		setArtikelNr(-1);
		setAutor("");
		setTitel("");
		setPreis(0.0);
		setStatus(false);
		setBestand(-1);
		setWarengruppe(-1);
	}

	/**
	 * Einen ueberladenen Konstruktor
	 * 
	 * @param autor
	 * @param titel
	 * @param preis
	 * @param status
	 * @param bestand
	 * @param warengruppe
	 */
	public Artikel(String autor, String titel, double preis, boolean status, int bestand, int warengruppe) {
		this();

		setAutor(autor);
		setTitel(titel);
		setPreis(preis);
		setStatus(status);
		setBestand(bestand);
		setWarengruppe(warengruppe);
	}

	/**
	 * Einen ueberladenen Konstruktor
	 * 
	 * @param artikelNr
	 * @param author
	 * @param titel
	 * @param preis
	 * @param status
	 * @param bestand
	 * @param warengruppe
	 */
	public Artikel(int artikelNr, String autor, String titel, double preis, boolean status, int bestand,
			int warengruppe) {

		this();

		setArtikelNr(artikelNr);
		setAutor(autor);
		setTitel(titel);
		setPreis(preis);
		setStatus(status);
		setBestand(bestand);
		setWarengruppe(warengruppe);
	}


	/**
	 * Überladene toString()-Methode für Objekt Artikel
	 * 
	 * return artikelString
	 */
	public String toString() {
		String artikelString = " Artikel " + getArtikelNr() + ": " + getTitel() + " \t" + getAutor() + "\t"
				+ getPreis() + " ";
		return artikelString;
	}

	/**
	 * @return artikelNr
	 */
	public int getArtikelNr() {
		return artikelNr.get();
	}

	/**
	 * @return autor
	 */
	public String getAutor() {
		return autor.get();
	}

	/**
	 * @return titel
	 */
	public String getTitel() {
		return titel.get();
	}

	/**
	 * @return preis
	 */
	public double getPreis() {
		return preis.get();
	}

	/**
	 * @return status
	 */
	public boolean getStatus() {
		return status.get();
	}

	/**
	 * @return bestand
	 */
	public int getBestand() {
		return bestand.get();
	}

	/**
	 * @return warengruppe
	 */
	public int getWarengruppe() {
		return warengruppe.get();
	}

	/**
	 * @param artikelNr das zu setzende Objekt artikelNr
	 */
	public void setArtikelNr(int artikelNr) {
		this.artikelNr.set(artikelNr);
	}

	/**
	 * @param autor das zu setzende Objekt autor
	 */
	public void setAutor(String autor) {
		this.autor.set(autor);
	}

	/**
	 * @param titel das zu setzende Objekt titel
	 */
	public void setTitel(String titel) {
		this.titel.set(titel);
	}

	/**
	 * @param preis das zu setzende Objekt preis
	 */
	public void setPreis(double preis) {
		this.preis.set(preis);
	}

	/**
	 * @param status das zu setzende Objekt status
	 */
	public void setStatus(boolean status) {
		this.status.set(status);
	}

	/**
	 * @param bestand das zu setzende Objekt bestand
	 */
	public void setBestand(int bestand) {
		this.bestand.set(bestand);
	}

	/**
	 * @param warengruppe das zu setzende Objekt warengruppe
	 */
	public void setWarengruppe(int warengruppe) {
		this.warengruppe.set(warengruppe);
	}

	
	
	

}
