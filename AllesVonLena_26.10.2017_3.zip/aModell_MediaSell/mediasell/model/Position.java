package mediasell.model;

import java.sql.SQLException;

import mediasell.datenbank.beans.ArtikelBean;

public class Position {
	int kassenvorgangID;


	int artikelNr;
	int anzahl;
	
	/**
	 * Konstruktor
	 */
	public Position() {
		this.kassenvorgangID = -1;
		this.artikelNr = -1;
		this.anzahl = -1;
	}
	
	
	/**
	 * Konstruktor
	 * @param rechnungId
	 * @param artikelNr
	 * @param anzahl
	 */
	public Position(int kassenvorgangID, int artikelNr, int anzahl) {
		this.kassenvorgangID = kassenvorgangID;
		this.artikelNr = artikelNr;
		this.anzahl = anzahl;
	}

	

	/**
	 * Konstruktor
	 * @param kassenvorgangID
	 * @param artikel
	 * @param anzahl
	 */
	public Position(int kassenvorgangID, Artikel artikel, int anzahl) {
		this.kassenvorgangID = kassenvorgangID;
		this.artikelNr = artikel.getArtikelNr();
		this.anzahl = anzahl;
	}	


	/**
	 * Konstruktor
	 * @param artikel
	 * @param anzahl
	 */
	public Position( Artikel artikel, int anzahl) {

		this.artikelNr = artikel.getArtikelNr();
		this.anzahl = anzahl;
	}	
	
	

	public String toString() {
		String positionString = " P " + getKassenvorgangID() +  ": " +  getArtikel(getArtikelNr()).toString() +  " ";
		return positionString;
	}


//-----------------------Getter/Setter-----------------------------------//
int getKassenvorgangID() {
 		return kassenvorgangID;
	}



/** Getter-Methode 
 * @param artikelNr
 * @return artikel 
 */
private Artikel getArtikel(int artikelNr) {

	Artikel artikel = null;
	try {
		artikel = ArtikelBean.getArtikel(artikelNr);
	} catch (SQLException e) {
		e.printStackTrace();
	}
	
	return artikel;
	}





//----------------------------------------Getter/Setter--------------------------------------//

	public int getArtikelNr() {
		return artikelNr;
	}

	public int getAnzahl() {
		return anzahl;
	}

	
}
