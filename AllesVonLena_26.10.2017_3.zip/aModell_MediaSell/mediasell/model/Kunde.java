package mediasell.model;


import java.util.ArrayList;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import mediasell.util.UtilMS;

/**
 * @author Alfa
 * 
 */
public class Kunde {
	/**
	 * Kunde parameter
	 */
	private IntegerProperty kundeNr; // Kunde-Nr.
	private StringProperty vorname; // Kunde-Vorname
	private StringProperty nachname; // Kunde-Nachname
	private StringProperty strasse; // Kunde-Strasse
	private StringProperty hausnr; // Kunde-hausnr
	private StringProperty plz; // Kunde-plz
	private StringProperty stadt; // Kunde-Stadt
	private StringProperty email; // Kunde-email
	private StringProperty telefonNr; // Kunde - telefonNr
	private IntegerProperty zahlungsart; // Kunde-Zahlungsart
	private BooleanProperty status; // Kunde-Status: Aktiv (true), Inaktiv (False)
	





	static UtilMS util = new UtilMS(); // Objekt für die Arbeit mit Utiliten

	/**
	 * Konstruktor
	 */
	private Kunde() {
		this.kundeNr = new SimpleIntegerProperty();
		this.vorname = new SimpleStringProperty();
		this.nachname = new SimpleStringProperty();
		this.strasse = new SimpleStringProperty();
		this.hausnr = new SimpleStringProperty();
		this.plz = new SimpleStringProperty();
		this.stadt = new SimpleStringProperty();
		this.email = new SimpleStringProperty();
		this.telefonNr = new SimpleStringProperty();
		this.zahlungsart = new SimpleIntegerProperty();
		this.status = new SimpleBooleanProperty();
		
		setKundeNr(-1);
		setVorname("");
		setNachname("");
		setStrasse("");
		setHausnr("");
		setPlz("");
		setStadt("");
		setEmail("");
		setTelefonNr("");
		setZahlungsart(-1);
		setStatus(false);


		
	}

 

	/**
	 * Ueberladenen Konstruktor Kunde wird mit den Гјbergebenen Werten
	 * initialisiert
	 * 
	 * @param vorname
	 * @param nachname
	 * @param strasse
	 * @param hausnr
	 * @param plz
	 * @param stadt
	 * @param email
	 * @param telefonNr
	 * @param zahlungsart
	 * @param status
	 */
	public Kunde(int kundeNr, String vorname, String nachname, String strasse,
			String hausnr, String plz, String stadt, String email,
			String telefonNr, int zahlungsart, boolean status) {
		
		
		this();
		
		setKundeNr(kundeNr);
		setVorname(vorname);
		setNachname(nachname);
		setStrasse(strasse);
		setHausnr(hausnr);
		setPlz(plz);
		setStadt(stadt);
		setEmail(email);
		setTelefonNr(telefonNr);
		setZahlungsart(zahlungsart);
		setStatus(status);
	}

	public Kunde(String vorname, String nachname, String strasse,
			String hausnr, String plz, String stadt, String email,
			String telefonNr, int zahlungsart, boolean status) {
		this();
		setVorname(vorname);
		setNachname(nachname);
		setStrasse(strasse);
		setHausnr(hausnr);
		setPlz(plz);
		setStadt(stadt);
		setEmail(email);
		setTelefonNr(telefonNr);
		setZahlungsart(zahlungsart);
		setStatus(status);
	}

	@Override
	public String toString() {
		return "Kunde [kundeNr=" + getKundeNr() + ", vorname=" + getVorname()
				+ ", nachname=" + getNachname() + ", strasse=" + getStrasse()
				+ ", hausnr=" + getHausnr() + ", plz=" + getPlz() + ", stadt=" + getStadt()
				+ ", email=" + getEmail() + ", telefonNr=" + getTelefonNr()
				+ ", zahlungsart=" + getZahlungsart() + ", status=" + isStatus() + "]";
	}

	/**
	 * Methode sucht alle Rechnungen für einen bestimten Kunde
	 * 
	 * @param kunde
	 *            Kunde
	 * @return Liste mit Rechnungen fuer einen Kunde
	 */
	public ObservableList<Rechnung> sucheRechnung() {

		ObservableList<Rechnung> kvListe = Kassenvorgangliste.kassenvorgangListe;
		ObservableList<Rechnung> kassenvorgangListeSuchen = FXCollections.observableArrayList();

		int kundeNr = this.getKundeNr();

		for (Rechnung rechnung : kvListe) {

			if (rechnung.getKundeNr() == kundeNr) {
				// System.out.println(rechnung.getNr());
				kassenvorgangListeSuchen.add(rechnung);
			}
		}

		return kassenvorgangListeSuchen;
	}

	/**
	 * Methode ducht alle Rechnungen für einen bestimten Kunde und ein
	 * bestimmtes Datum
	 * 
	 * @param datum
	 * @param kassenvorgangListe
	 * @return Liste mit Rechnungen fuer einen Kunde und ein bestimmtes Datum
	 */
	public ArrayList<Rechnung> sucheRechnung(Kunde kunde, String datum,
			ArrayList<Rechnung> kassenvorgangListe) {

		ArrayList<Rechnung> kassenvorgangListeSuchen = new ArrayList<Rechnung>();
		int kundeNr = kunde.getKundeNr();

		for (Rechnung rechnung : kassenvorgangListe) {
			if (rechnung.getKundeNr() == kundeNr) {
				if (rechnung.getDatum() == datum) {
					kassenvorgangListeSuchen.add(rechnung);
				}
			}
		}

		return kassenvorgangListeSuchen;
	}



	/**
	 * Methode bildet eine Liste mit Objekten Kunde aus der StringListe
	 * 
	 * @param kundeListeString
	 * @return Liste mit Objekten Kunde
	 */
	public static ObservableList<Kunde> makeKundeListe(ArrayList<String[]> kundeListeString) {

		int kundeNr;
		String vorname;
		String nachname;
		String strasse;
		String hausnr;
		String plz;
		String stadt;
		String email;
		String telefonNr;
		int zahlungsart;
		boolean status = false;

		ObservableList<Kunde> alleKundeListe = FXCollections.observableArrayList();

		for (String[] list : kundeListeString) {

			kundeNr = Integer.parseInt(list[0]);
			vorname = list[1];
			nachname = list[2];
			strasse = list[3];
			hausnr = list[4];
			plz = list[5];
			stadt = list[6];

			email = list[7];
			telefonNr = list[8];
			zahlungsart = Integer.parseInt(list[9]);
			status = util.getStatus(list[10]);

			Kunde kunde = new Kunde(kundeNr, vorname, nachname, strasse,
					hausnr, plz, stadt, email, telefonNr, zahlungsart, status);

			alleKundeListe.add(kunde);

		}

		return alleKundeListe;
	}




	// ----------------------Getter / Setter---------------------------------//

	public void setKundeNr(int kundeNr) {
		this.kundeNr.set(kundeNr);
	}
	
	public void setVorname(String vorname) {
		this.vorname.set(vorname);
 		
	}

	public void setNachname(String nachname) {
		this.nachname.set(nachname);
	}

	public void setStrasse(String strasse) {
		this.strasse.set(strasse);
	}

	public void setHausnr(String hausnr) {
		this.hausnr.set(hausnr);
	}

	public void setPlz(String plz) {
		this.plz.set(plz);
	}

	public void setStadt(String stadt) {
		this.stadt.set(stadt);
	}

	public void setEmail(String email) {
		this.email.set(email);
	}

	public void setTelefonNr(String telefonNr) {
		this.telefonNr.set(telefonNr);
	}

	public void setZahlungsart(int zahlungsart) {
		this.zahlungsart.set(zahlungsart);
	}

	public void setStatus(boolean status) {
		this.status.set(status);
	}

	public int getKundeNr() {

		return kundeNr.get();
	}

	public String getVorname() {
		return vorname.get();
	}

	public String getNachname() {
		return nachname.get();
	}

	public String getStrasse() {
		return strasse.get();
	}

	public String getHausnr() {
		return hausnr.get();
	}

	public String getPlz() {
		return plz.get();
	}

	public String getStadt() {
		return stadt.get();
	}

	public String getEmail() {
		return email.get();
	}

	public String getTelefonNr() {
		return telefonNr.get();
	}

	public int getZahlungsart() {
		return zahlungsart.get();
	}

	public boolean isStatus() {
		return status.get();
	}



	/**
	 * Methode kopiert einen aktuelen Kunde in Objekt neuKunde
	 * 
	 * @return Kopie von Kunde
	 */
	public Kunde makeKopie() {
		Kunde neuKunde = new Kunde();

		neuKunde.kundeNr = this.kundeNr;
		neuKunde.vorname = this.vorname;
		neuKunde.nachname = this.nachname;
		neuKunde.strasse = this.strasse;
		neuKunde.hausnr = this.hausnr;
		neuKunde.plz = this.plz;
		neuKunde.stadt = this.stadt;
		neuKunde.email = this.email;
		neuKunde.telefonNr = this.telefonNr;
		neuKunde.zahlungsart = this.zahlungsart;
		neuKunde.status = this.status;

		return neuKunde;
	}

	// ----------------------Getter / Setter---------------------------------//

}
