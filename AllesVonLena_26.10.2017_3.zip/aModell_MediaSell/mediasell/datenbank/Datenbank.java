package mediasell.datenbank;

import java.sql.SQLException;

import mediasell.datenbank.beans.ArtikelBean;
import mediasell.datenbank.verbindung.SQLiteDatenbankverbindung;


/**
 * Klasse zur Steuerung der Datenbankvorg�nge. Definiert als Singelton:
 * https://de.wikibooks.org/wiki/Muster:_Java:_Singleton
 * 
 * Java ist auch eine Insel: Seiten 823 - 827
 */
public class Datenbank extends SQLiteDatenbankverbindung {
	
		
	private static final String DB_FILE = PfadUndNameDerDatenbankdatei.dbPfadUndName;
			
	//		"Z:\\MediaSell.sqlite";
	//private static final String DB_FILE = "Z:\\MEDIASELL_DB\\MediaSell.sqlite";
	
	private static Datenbank datenbank;
	
	/**
	 * private Konstruktor
	 * @throws ClassNotFoundException 
	 */
	private Datenbank() throws ClassNotFoundException {
		super(DB_FILE);
		
	}
	
	/**
	 * Klassenmethode, die die Instanz der Datenbankklasse zur�ckgibt
	 * 
	 * @return Instanz der Datenbank-Klasse
	 */
	public static Datenbank getInstance() {
		if (datenbank == null) {
			try {
				datenbank = new Datenbank();
				datenbank.init();
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
				datenbank = null;
			}
		}
		return datenbank;
	}
	
	
	/**
	 * Methode zum Initialisieren der Datenbankverbindung, Vorbereiten der
	 * Statements und Herstellen der korrekten Datenbankversion
	 */
	private void init() {
		// Datenbankverbindung herstellen
		connect();
		
		// Version der Datenbank �berpr�fen und ggf aktualisieren
		/*try {
			upgrade();
		} catch (SQLException e) {
			e.printStackTrace();
		}*/
		
		// Statements vorbereiten
		try {
			ArtikelBean.prepareStatements();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void disconnect() {
		try {
			ArtikelBean.closeStatements();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		super.disconnect();
	}

	
	/**
	 * Upgrade-Funktion der Datenbank, um bei einer neuen Programmversion gleich auch die Datenbank
	 * zu migrieren.
	 * @throws SQLException 
	 */
/*	private void upgrade() throws SQLException {
		// Datenbankversion holen
		PreparedStatement pstmt = getPreparedStatement(SQLStatements.GET_DB_VERSION);
		ArrayList<String[]> dbversion = executeQueryAsList(pstmt);
		try {
			pstmt.close();
		} catch (SQLException e) {
		}
		int oldDBVersion = Integer.parseInt(dbversion.get(1)[0]);
		
		if (oldDBVersion == SQLStatements.DB_VERSION) {
			System.out.println("Die Datenbank ist bereits aktuell.");
			return;
		}
		
		boolean result = true;

		switch (oldDBVersion) {
		case 0: {
			// Befehle f�r Upgrade auf Version 1
			result = result && execute(SQLStatements.CREATE_TABLE_UMSATZ);
			
			
			// KEIN break! Denn wir wollen, dass immer die Datenbank auf die
			// neuste Version gebracht wird!!!
		}
		case 1: {
			// Befehle f�r Upgrade auf Version 2...

			// System.out.println("Upgrade auf DB-Version 2 durchgef�hrt.");
		}
		}
		
		// Neue Datenbankversion setzen
		if (result) {
			result = execute(SQLStatements.SET_DB_VERSION + SQLStatements.DB_VERSION);
		}
		
		// Wenn alles erfolgreich war und es keine Exception oder ein false gab,
		// wird ein commit ausgef�hrt
		if (result) {
			commit();
			System.out.println("Upgrade war insgesamt erfolgreich.");
		} else {
			rollback();
			System.out.println("Upgrade wurde r�ckg�ngig gemacht.");
		}
	}*/
	
	
	
}
