package mediasell.datenbank.beans;

import java.sql.SQLException;

import mediasell.datenbank.Datenbank;
import mediasell.datenbank.beans.NummernkreiseBean.Nummernkreis;
import mediasell.model.Kunde;

public class DBMethodeKunde {
	DBMethode dbM = new DBMethode();	
	Warnungen warnung = new Warnungen();
	
	public boolean kundeMakeAktiv(Kunde kunde) throws SQLException, ClassNotFoundException {
		boolean erfolg = false;
		String update = "UPDATE \"Kunde\" SET status = \"true\" WHERE \"kundeNr\" = " 
		+ kunde.getKundeNr() + ";";
		
		int result = Datenbank.getInstance().executeUpdate(update);
		
		if (result ==1) {
			Datenbank.getInstance().commit();
		} else {
			Datenbank.getInstance().rollback();
		}
		
		
		return erfolg;
	}

	public boolean kundeMakeInaktiv(Kunde kunde) throws SQLException, ClassNotFoundException {
		boolean erfolg = false;
		String update = "UPDATE \"Kunde\" SET status = \"false\" WHERE \"kundeNr\" = " 
		+ kunde.getKundeNr() + ";";
	
		
		
		int result = Datenbank.getInstance().executeUpdate(update);
		
		if (result ==1) {
			Datenbank.getInstance().commit();
		} else {
			Datenbank.getInstance().rollback();
		}
		
		
		return erfolg;
	}
	
	public int kundeBearbeiten(Kunde kundeKorrektur) throws SQLException, ClassNotFoundException {

		String vornameUpdate = kundeKorrektur.getVorname().trim();
		String nachnameUpdate = kundeKorrektur.getNachname().trim();
		String strasseUpdate = kundeKorrektur.getStrasse().trim();
		String hausnrUpdate = kundeKorrektur.getHausnr().trim();
		String plzUpdate = kundeKorrektur.getPlz().trim();
		String stadtUpdate = kundeKorrektur.getStadt().trim();
		String emailUpdate = kundeKorrektur.getEmail().trim();
		String telefonNrUpdate = kundeKorrektur.getTelefonNr().trim();
		int zahlungsartUpdate = kundeKorrektur.getZahlungsart();
		Boolean status = kundeKorrektur.isStatus();

		String update = "UPDATE \"Kunde\" SET " + "vorname = \" " + vornameUpdate + " \" , " + "nachname = \" "
				+ nachnameUpdate + " \" , " + "strasse = \" " + strasseUpdate + " \" ," + "hausnr = \" " + hausnrUpdate
				+ " \" , " + "plz = \" " + plzUpdate + " \" , " + "stadt = \" " + stadtUpdate + " \" , " + "email = \" "
				+ emailUpdate + " \" , " + "telefonNr = \" " + telefonNrUpdate + " \" , " + "zahlungsart = \" "
				+ zahlungsartUpdate + " \" , " + "status = \"" + status + " \" WHERE \"kundeNr\" = " + kundeKorrektur.getKundeNr()
				+ " ;";

		//Datenbank.getInstance().executeUpdate(update);
		
		int result = Datenbank.getInstance().executeUpdate(update);
		
		if (result ==1) {
			Datenbank.getInstance().commit();
		} else {
			Datenbank.getInstance().rollback();
		}
		
		return kundeKorrektur.getKundeNr();
	}	
	


	public int kundeEinfuegen(Kunde kunde) throws SQLException, ClassNotFoundException,  Exception  {
		int neueKundeNr = getNeuKundeNr();
		
		if (neueKundeNr < 0) { 
			throw new Exception(warnung.unplausibeleKundeNr(neueKundeNr));
			}
		else {
		String insert = " INSERT INTO Kunde ('kundeNr', 'vorname','nachname', 'strasse', 'hausnr', 'plz', 'stadt', 'email',"
				+ " 'telefonNr', 'zahlungsart', 'status') VALUES (" + getNeuKundeNr() + "  , " + "'"
				+ kunde.getVorname() + "', '" + kunde.getNachname() + "', '" + kunde.getStrasse() + "', '"
				+ kunde.getHausnr() + "', '" + kunde.getPlz() + "', '" + kunde.getStadt() + "', '" + kunde.getEmail()
				+ "', '" + kunde.getTelefonNr() + "', " + kunde.getZahlungsart() + ", " + "'" + kunde.isStatus() + "');";

		int result = Datenbank.getInstance().executeUpdate(insert);
		
		if (result ==1) {
			Datenbank.getInstance().commit();
		} else {
			Datenbank.getInstance().rollback();
		}
		}
		
		return neueKundeNr;

	}

	private int getNeuKundeNr() throws SQLException, ClassNotFoundException {
		return NummernkreiseBean.getNeueNr(Nummernkreis.KUNDE);
	}	
	
	

}
