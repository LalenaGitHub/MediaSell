package mediasell.datenbank.beans;

import java.sql.ResultSet;
import java.sql.SQLException;

import mediasell.datenbank.Datenbank;

public class NummernkreiseBean {
	
	public enum Nummernkreis {
		KUNDE, RECHNUNG, KASSENVORGANG
	}
	
	public static  int getNeueNr(Nummernkreis nummernkreis) throws SQLException {
		String sql = null;
		switch (nummernkreis) {
		case KUNDE: sql = "SELECT MAX (kundeNr) AS maxNr FROM Kunde;";
			break;
		case KASSENVORGANG: sql = "SELECT MAX (kassenVorgangID) AS maxNr FROM Kassenvorgang;";
			break;
		case RECHNUNG: sql = "SELECT MAX (kassenVorgangID) AS maxNr FROM Kassenvorgang;";
			break;
		default:
			break;
		
		}
		int neueNr = 1;

		ResultSet rs = Datenbank.getInstance().executeQuery(sql);
		if (rs.next()) {
			neueNr = rs.getInt(1);
		}
		
		neueNr++;
		
		return neueNr;
	}	
}
