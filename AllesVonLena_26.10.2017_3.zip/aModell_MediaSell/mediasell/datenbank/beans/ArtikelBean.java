package mediasell.datenbank.beans;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import mediasell.datenbank.Datenbank;
import mediasell.model.Artikel;

public class ArtikelBean {
	
	private static PreparedStatement pstmtSelectAll;
	private static PreparedStatement pstmtSelect;
	private static PreparedStatement pstmtUpdateBestand;
	/*private static PreparedStatement pstmtInsert;
	private static PreparedStatement pstmtDelete;
	private static PreparedStatement pstmtUpdate;*/
	
	private final static String SELECT_ALL = "SELECT artikelNr, author, titel, preis, status, bestand, warengruppe FROM vArtikel;";
	private final static String SELECT = "SELECT artikelNr, author, titel, preis, status, bestand, warengruppe FROM vArtikel WHERE artikelNr = ?;";
	private final static String UPDATE_BESTAND = "UPDATE Artikel SET Bestand = ? WHERE artikelNr = ?";
	/*private final static String INSERT = "INSERT INTO vArtikel (artikelNr, author, titel, preis, status, bestand, warengruppe) VALUES (?, ?, ?, ?, ?, ?, ?);";
	private final static String UPDATE = "UPDATE vArtikel SET artikelNr = ?, author, titel = ?, preis = ?, status = ?, bestand = ?, warengruppe = ? WHERE artikelNr = ?;";
	private final static String DELETE = "DELETE FROM vArtikel WHERE artikelNr = ?;";*/
	
	
	public static void prepareStatements() throws SQLException {
		pstmtSelectAll = Datenbank.getInstance().getPreparedStatement(SELECT_ALL);
		pstmtSelect = Datenbank.getInstance().getPreparedStatement(SELECT);
		pstmtUpdateBestand = Datenbank.getInstance().getPreparedStatement(UPDATE_BESTAND);
		/*pstmtInsert = Datenbank.getInstance().getPreparedStatement(INSERT);
		pstmtDelete = Datenbank.getInstance().getPreparedStatement(DELETE);
		pstmtUpdate = Datenbank.getInstance().getPreparedStatement(UPDATE);*/
	}
	
	public static void closeStatements() throws SQLException {
		pstmtSelectAll.close();
		pstmtSelect.close();
		pstmtUpdateBestand.close();
		/*pstmtInsert.close();
		pstmtDelete.close();
		pstmtUpdate.close();*/
	}
	
	public static ObservableList<Artikel> getArtikelliste() throws SQLException {
		ObservableList<Artikel> result = FXCollections.observableArrayList();

		ResultSet rs = pstmtSelectAll.executeQuery();
		
		while (rs.next()) {
			Artikel neu = new Artikel(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDouble(4), rs.getBoolean(5), rs.getInt(6), rs.getInt(7));
			result.add(neu);
		}
		
		return result;
	}
	
	public static Artikel getArtikel(int artikelNr) throws SQLException {
		Artikel result = null;

		pstmtSelect.setInt(1,  artikelNr);;
		ResultSet rs = pstmtSelect.executeQuery();
		
		if (rs.next()) {
			result = new Artikel(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDouble(4), rs.getBoolean(5), rs.getInt(6), rs.getInt(7));
		}
		
		return result;
	}
	
	public static boolean updateArtikelBestand(int bestand, int artikelNr) throws SQLException {
		boolean result = false;
		
		pstmtUpdateBestand.setInt(1,  bestand);
		pstmtUpdateBestand.setInt(2,  artikelNr);
		
		if (pstmtUpdateBestand.executeUpdate() == 1) {
			result = true;
		}
		
		if (result) {
			Datenbank.getInstance().commit();
		} else {
			Datenbank.getInstance().rollback();
		}
	
		return result;
	}
	
	/*public static boolean deleteArtikel(int artikelNr) throws SQLException {
		boolean result = false;

		pstmtDelete.setInt(1,  artikelNr);;
		if (pstmtDelete.executeUpdate() == 1) {
			result = true;
		}
	
		return result;
	}
	
	private static boolean updateArtikel(Artikel artikel, int oldArtikelNr) throws SQLException {
		boolean result = false;
		
		pstmtUpdate.setInt(1,  artikel.getArtikelNr());
		pstmtUpdate.setString(2,  artikel.getAutor());
		pstmtUpdate.setString(3,  artikel.getTitel());
		pstmtUpdate.setDouble(4,  artikel.getPreis());
		pstmtUpdate.setBoolean(5,  artikel.getStatus());
		pstmtUpdate.setInt(6,  artikel.getBestand());
		pstmtUpdate.setInt(7,  artikel.getWarengruppe());
		pstmtUpdate.setInt(8,  oldArtikelNr);
		
		if (pstmtUpdate.executeUpdate() == 1) {
			result = true;
		}
	
		return result;
	}
	
	private static boolean insertArtikel(Artikel artikel) throws SQLException {
		boolean result = false;
		
		pstmtInsert.setInt(1,  artikel.getArtikelNr());
		pstmtInsert.setString(2,  artikel.getAutor());
		pstmtInsert.setString(3,  artikel.getTitel());
		pstmtInsert.setDouble(4,  artikel.getPreis());
		pstmtInsert.setBoolean(5,  artikel.getStatus());
		pstmtInsert.setInt(6,  artikel.getBestand());
		pstmtInsert.setInt(7,  artikel.getWarengruppe());

		if (pstmtInsert.executeUpdate() == 1) {
			result = true;
		}
	
		return result;
	}
	
	public static boolean saveArtikel(Artikel artikel, Integer oldArtikelNr) throws SQLException {
		boolean result;
		if (oldArtikelNr == null) {
			result = insertArtikel(artikel);
		} else {
			result = updateArtikel(artikel, oldArtikelNr);
		}
		
		if (result) {
			Datenbank.getInstance().commit();
		} else {
			Datenbank.getInstance().rollback();
		}
		
		return result;
	}*/
}
