package mediasell.datenbank.beans;

import java.sql.SQLException;

import javafx.collections.ObservableList;
import mediasell.datenbank.Datenbank;
import mediasell.datenbank.beans.NummernkreiseBean.Nummernkreis;
import mediasell.model.Artikel;
import mediasell.model.Kassenvorgangliste;
import mediasell.model.Position;
import mediasell.model.Rechnung;

public class DBMethodeRechnung {

	Warnungen warnung = new Warnungen();
	DBMethode dbM = new DBMethode();

	/**
	 * Methode storniert eine Rechnung
	 * 
	 * @param rechnung
	 * @throws Exception
	 */
	public void setStorno(Rechnung rechnung) throws Exception {

		System.out.println("Rechnungen gefunden: \n");
		for (Rechnung r : Kassenvorgangliste.kassenvorgangListe) {

			if (r.getKassenvorgangID() == rechnung.getKassenvorgangID()) {
				// System.out.println(rechnung.toString());
				dbSetStorno(rechnung);

			}

		}
	}

	/** Methode storniert Rechnung und erhöht Anzahl von stornierten Artikel  
	 * @param rechnung
	 * @throws SQLException
	 * @throws Exception
	 */
	private void dbSetStorno(Rechnung rechnung) throws SQLException, Exception {
		int kassenvorgangID = rechnung.getKassenvorgangID();

		if (kassenvorgangID < 0) {
			new Exception(warnung.unplausibeleKassenvorgangID(kassenvorgangID));
		} else {
			alleArtikelStornieren(rechnung);
			rechnungStornieren(rechnung);
		}
	}


	/**
	 * Methode Storniert die Rechnung (set Status Storno=true)
	 * @param rechnung
	 * @throws SQLException
	 */
	private void rechnungStornieren(Rechnung rechnung) throws SQLException {
		String update = "UPDATE  \"Kassenvorgang\" SET \"storno\" = \"true\" "
				+ " WHERE \"kassenvorgangID\"= " + rechnung.getKassenvorgangID();

		Datenbank.getInstance().executeUpdate(update);
	}

	/** Methode stornieret alle Artikel in DB für eine bestimmte Rechnung:
	 * Menge-Bestand-Erhöhung
	 * @param rechnung
	 * @throws SQLException
	 * @throws Exception
	 */
	private void alleArtikelStornieren(Rechnung rechnung) throws SQLException,
			Exception {
		DBMethodeArtikel dbArtikel = new DBMethodeArtikel();

		ObservableList<Position> gesamteBestellung = rechnung.getGesamteBestellung();
		int artikelNr = 0;
		int zugebuchteMenge = 0;
		
		for (Position position : gesamteBestellung) {
			artikelNr = position.getArtikelNr();
			zugebuchteMenge = position.getAnzahl();
		}

		Artikel artikel = ArtikelBean.getArtikel(artikelNr);

		dbArtikel.bestandErhoehen(zugebuchteMenge, artikel);
		dbArtikel.setStatusAktiv(artikel);
		
	}
	
	/**
	 * Methode einfügt eine neue Rechnung in DB-Tabelle Kassenvorgang
	 * @param rechnung
	 * @return neue RechnungNr
	 * @throws SQLException
	 * @throws ClassNotFoundException
	 * @throws Exception
	 */
	public int rechnungEinfuegen(Rechnung rechnung) throws SQLException, ClassNotFoundException,  Exception  {
		int neueRechnungNr = getNeueRechnungNr();
		ObservableList<Position> gesamteBestellung = rechnung.getGesamteBestellung();
		int artikelNr = 0;
		int anzahl = 0;
		
		String insert = "";
		 
		int neueKvNr = getNeueKvNr();
		
		if (neueRechnungNr < 0) { 
			throw new Exception(warnung.unplausibeleKassenvorgangID(neueRechnungNr));
			}
		else {
			
			for (Position position : gesamteBestellung) {
				artikelNr = position.getArtikelNr();
				anzahl = position.getAnzahl();	
			
			
		
		insert = insert +  " INSERT INTO Kassenvorgang "
				+ "(\"kvNr\",  \"kassenvorgangID\", \"aid\", \"kid\", "
				+ " \"anzahl\", \"datum\", \"storno\") "
				+ " VALUES (" 
				+ neueKvNr + "  ,"
				+ neueRechnungNr + "  , "
				+ artikelNr + ", " 
				+ rechnung.getKundeNr() + ", " 
				+ anzahl + ", '" 
				+ rechnung.getDatum() + "', '"
				+ rechnung.getStorno() + "');";

		
			}

		
		
			Datenbank.getInstance().executeUpdate(insert);
		}
		
		return neueRechnungNr;

	}
	
	/**
	 * Methode gibt eine neue kvNr aus DB-Tabelle Kassenvorgang 
	 * @return neue kvNr 
	 * @throws SQLException
	 */
	private int getNeueKvNr() throws SQLException {
		return NummernkreiseBean.getNeueNr(Nummernkreis.KUNDE);
	}
	
	private int getNeueRechnungNr() throws SQLException {
		return NummernkreiseBean.getNeueNr(Nummernkreis.RECHNUNG);
	}	

	
	
	
	
	
}
