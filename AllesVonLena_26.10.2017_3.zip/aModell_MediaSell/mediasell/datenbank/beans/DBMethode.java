package mediasell.datenbank.beans;

import java.sql.SQLException;
import java.util.ArrayList;

import mediasell.SQLAbfrage;
import mediasell.datenbank.Datenbank;
import mediasell.model.Kassenvorgangliste;
import mediasell.model.Kunde;
import mediasell.model.Kundeliste;

public class DBMethode {
	

	
	public void ini() throws Exception {
		try {
						
			dbDatenInListeAuslesen();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void listeAktualisieren() throws SQLException {
		dbDatenInListeAuslesen();
	}

	void dbDatenInListeAuslesen() throws SQLException {
		dbKundeInListeAuslesen();
		//dbArtikelInListeAuslesen();
		dbKassenvorgangInListeAuslesen();
	}

	private void dbKassenvorgangInListeAuslesen() throws SQLException {
		// View Kassenvorgang --> Liste kassenvorgangListe
		ArrayList<String[]> kassenvorgangListeString = Datenbank.getInstance().executeQueryAsList(SQLAbfrage.vKKA);
		 Kassenvorgangliste.makeKassenvorgangListe(kassenvorgangListeString) ;

	}

	/*private void dbArtikelInListeAuslesen() throws SQLException {
		// View ---> Liste artikelListe
		ArrayList<String[]> artikelListeString = Datenbank.getInstance().executeQueryAsList(SQLAbfrage.vARTIKEL);
		Artikelliste.artikelListe = Artikelliste.makeArtikelListe(artikelListeString);

	}*/

	private void dbKundeInListeAuslesen() throws SQLException {
		// Tabelle ---> Liste kundeListe
		ArrayList<String[]> kundeListeString = Datenbank.getInstance().executeQueryAsList(SQLAbfrage.vKUNDE);
		Kundeliste.kundeListe = Kunde.makeKundeListe(kundeListeString);

	}

	void closeMediaSell() {
		Datenbank.getInstance().disconnect();
	}
}
