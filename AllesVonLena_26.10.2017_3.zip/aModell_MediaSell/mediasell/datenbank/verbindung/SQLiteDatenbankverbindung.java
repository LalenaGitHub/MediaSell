package mediasell.datenbank.verbindung;

import java.sql.DriverManager;
import java.sql.SQLException;

public class SQLiteDatenbankverbindung extends Datenbankschnittstelle {
	
	private String datenbankdatei;

	/**
	 * Erstellt eine Datenbankverbindung zur der �bergebenen Datenbankdatei
	 * 
	 * @param datenbankdatei Pfad und Name der Datenbankdatei
	 * @throws ClassNotFoundException wird geworfen, wenn der Treiber nicht gefunden wurde
	 */
	public SQLiteDatenbankverbindung(String datenbankdatei) throws ClassNotFoundException {
		super("org.sqlite.JDBC");
		
		this.datenbankdatei = datenbankdatei;
		connect();
	}

	/**
	 * Diese Methode dient der Erstellung der Verbindung zur SQLite-Datenbank.
	 * 
	 * @return true bei erfolgreicher Verbindung zur Datenbank, false andernfalls.
	 */
	@Override
	public boolean connect() {
		
		if (con == null) {
			try {
				con = DriverManager.getConnection("jdbc:sqlite:" + datenbankdatei);
				
				// Verwenden von Transaktionen. Erst wenn wir ein commit absetzen, werden
				// die Daten in die Datenbank geschrieben
				con.setAutoCommit(false);
				System.out.println("DB erfolgreich verbunden");
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		}
		
		return true;
	}

}
