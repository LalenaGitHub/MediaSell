package mediasell.datenbank.verbindung;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

public abstract class Datenbankschnittstelle {
	
	/**
	 * Connection-Objekt, welches die Datenbankverbindung enth�lt
	 */
	protected Connection con;
	
	private ArrayList<PreparedStatement> pstmtList;
	
	/**
	 * Konstruktor, der die Informationen f�r den Treiber �bergeben bekommt und diesen auch l�d.
	 * 
	 * @param jdbcTreiber JDBC-Treiber f�r die Verbindung zur Datenbank
	 * @throws ClassNotFoundException wird geworfen, wenn der �bergebene Treiber nicht gefunden wurde
	 */
	public Datenbankschnittstelle(String jdbcTreiber) throws ClassNotFoundException {
		Class.forName(jdbcTreiber);
		
		con = null;
		pstmtList = new ArrayList<>();
	}
	
	/**
	 * Diese Methode dient der Erstellung der Verbindung zur Datenbank. Diese MUSS das
	 * Connection-Objekt 'con' korrekt setzen.
	 * 
	 * Empfehlung: AutoCommit auf false setzen
	 * 
	 * @return true bei erfolgreicher Verbindung zur Datenbank, false andernfalls.
	 */
	public abstract boolean connect();
	
	/**
	 * Trennt die Verbindung zur Datenbank.
	 */
	public void disconnect() {
		if (con != null) {
			
		
			// PreparedStatements schlie�en
			for (PreparedStatement pstmt : pstmtList) {
				try {
					pstmt.close();
					
				/* Sollte das Statement schon geschlossen sein, wird eine
				 * Fehlermeldung geworfen. Diese wird ignoriert und mit dem
				 * n�chsten weitergemacht
				 */
				} catch (SQLException e) {}
			}
			pstmtList.clear();
			
			try {
				con.close();
			} catch (SQLException e) {
			} finally {
				con = null;
			}
		}
	}
	
	/**
	 * F�hrt ein Commit aus. Alle noch offenen Transaktionen werden in die Datenbank geschrieben.
	 * 
	 * @throws SQLException wird geworfen, wenn ein Fehler beim Commit auftritt oder keine korrekte Verbindung zur Datenbank besteht
	 */
	public void commit() throws SQLException {
		if (con != null) {
			con.commit();
		}
	}
	
	/**
	 * F�hrt ein Rollback aus. Alle noch offenen Transaktionen werden r�ckg�ngig gemacht.
	 * 
	 * @throws SQLException wird geworfen, wenn ein Fehler beim Rollback auftritt oder keine korrekte Verbindung zur Datenbank besteht
	 */
	public void rollback() throws SQLException {
		if (con != null) {
			con.rollback();
		}
	}
	
	/**
	 * Diese Methode f�hrt eine SQL-Abfrage aus und liefert das Ergebnis als ResultSet zur�ck
	 * Im Fehlerfall wird die aufgetretene Exception zur�ckgegeben. Sollte keine Verbindung zur
	 * Datenbank bestehen wird null zur�ckgegeben.
	 * 
	 * @param sqlQuery SQL-Statement welches ausgef�hrt werden soll
	 * @return ResultSet der Abfrage oder null
	 * @throws SQLException wird geworfen, wenn ein Fehler in der �bergebenen SQL-Abfrage auftritt oder keine korrekte Verbindung zur Datenbank besteht
	 */
	public ResultSet executeQuery(String sqlQuery) throws SQLException {
		if (con != null) {
			Statement stmt = con.createStatement();
			return stmt.executeQuery(sqlQuery);
		}
		return null;
	}
	
	/**
	 * Diese Methode f�hrt eine SQL-Abfrage aus und liefert das Ergebnis als ArrayList zur�ck
	 * Im Fehlerfall wird die aufgetretene Exception zur�ckgegeben. Sollte keine Verbindung zur
	 * Datenbank bestehen wird null zur�ckgegeben. Das Ergebnis besteht mindestens aus den Namen
	 * der Spalten.
	 * 
	 * @param sqlQuery SQL-Statement welches ausgef�hrt werden soll
	 * @return ArrayList von String-Arrays mit den Inhalten der �bergebenen Abfrage oder null
	 * @throws SQLException wird geworfen, wenn ein Fehler in der �bergebenen SQL-Abfrage auftritt oder keine korrekte Verbindung zur Datenbank besteht
	 */
	public ArrayList<String[]> executeQueryAsList(String sqlQuery) throws SQLException {
		
		ResultSet rs = executeQuery(sqlQuery);
		
		ArrayList<String[]> result = resultSetToArrayList(rs);
		
		return result;
	}
	
	/**
	 * Diese Methode f�hrt ein PreparedStatement aus und liefert das Ergebnis als ResultSet zur�ck
	 * Im Fehlerfall wird die aufgetretene Exception zur�ckgegeben. Sollte keine Verbindung zur
	 * Datenbank bestehen wird null zur�ckgegeben.
	 * 
	 * @param pstmt PreparedStatement welches ausgef�hrt werden soll
	 * @return ResultSet der Abfrage oder null
	 * @throws SQLException wird geworfen, wenn ein Fehler in der �bergebenen SQL-Abfrage auftritt oder keine korrekte Verbindung zur Datenbank besteht
	 */
	public ResultSet executeQuery(PreparedStatement pstmt) throws SQLException {
		if (con != null) {
			return pstmt.executeQuery();
		}
		return null;
	}
	
	/**
	 * Diese Methode f�hrt ein PreparedStatement aus und liefert das Ergebnis als ArrayList zur�ck
	 * Im Fehlerfall wird die aufgetretene Exception zur�ckgegeben. Sollte keine Verbindung zur
	 * Datenbank bestehen wird null zur�ckgegeben. Das Ergebnis besteht mindestens aus den Namen
	 * der Spalten.
	 * 
	 * @param sqlQuery PreparedStatement welches ausgef�hrt werden soll
	 * @return ArrayList von String-Arrays mit den Inhalten der �bergebenen Abfrage oder null
	 * @throws SQLException wird geworfen, wenn ein Fehler in der �bergebenen SQL-Abfrage auftritt oder keine korrekte Verbindung zur Datenbank besteht
	 */
	public ArrayList<String[]> executeQueryAsList(PreparedStatement pstmt) throws SQLException {
		
		ResultSet rs = executeQuery(pstmt);
		
		ArrayList<String[]> result = resultSetToArrayList(rs);
		
		return result;
	}
	
	/**
	 * F�hrt einen beliebigen SQL-Befehl aus. Liefert true zur�ck, wenn kein Fehler
	 * bei der Ausf�hrung auftrat. Wenn doch, dann ist das Ergebnis false.
	 * 
	 * @param sqlStatement SQL-Statement welches ausgef�hrt werden soll
	 * @return true, wenn das Statement ausgef�hrt wurde, false andernfalls
	 * @throws SQLException wird geworfen, wenn ein Fehler in dem �bergebenen SQL-Statement auftritt oder keine korrekte Verbindung zur Datenbank besteht
	 */
	public boolean execute(String sqlStatement) throws SQLException {
		if (con != null) {
			Statement stmt = con.createStatement();
			stmt.execute(sqlStatement);
			return true;
		}
		return false;
	}
	
	/**
	 * F�hrt einen beliebigen SQL-Befehl aus den DML-Befehlen aus. Die Funktion liefert
	 * als Ergebnis die Anzahl der Zeilen, die ver�ndert wurden. Gibt es einen Fehler, wird -1
	 * zur�ckgegeben.
	 * 
	 * @param sqlStatement SQL-Statement welches ausgef�hrt werden soll
	 * @return Anzahl der ver�nderten Zeilen oder -1
	 * @throws SQLException wird geworfen, wenn ein Fehler in dem �bergebenen SQL-Statement auftritt oder keine korrekte Verbindung zur Datenbank besteht
	 */
	public int executeUpdate(String sqlStatement) throws SQLException {
		if (con != null) {
			Statement stmt = con.createStatement();
			return stmt.executeUpdate(sqlStatement);
		}
		return -1;
	}
	
	/**
	 * F�hrt einen beliebigen SQL-Befehl aus den DML-Befehlen aus. Die Funktion liefert
	 * als Ergebnis die Anzahl der Zeilen, die ver�ndert wurden. Gibt es einen Fehler, wird -1
	 * zur�ckgegeben.
	 * 
	 * @param pstmt Prepared-SQL-Statement welches ausgef�hrt werden soll
	 * @return Anzahl der ver�nderten Zeilen oder -1
	 * @throws SQLException wird geworfen, wenn ein Fehler in dem �bergebenen SQL-Statement auftritt oder keine korrekte Verbindung zur Datenbank besteht
	 */
	public int executeUpdate(PreparedStatement pstmt) throws SQLException {
		if (con != null) {
			return pstmt.executeUpdate();
		}
		return -1;
	}
	
	/**
	 * F�hrt alle SQl-Befehle in der �bergebenen Datei aus. Gibt true zur�ck, wenn
	 * alle Befehle erfolgreich ausgef�hrt werden konnten und false im Fehlerfall.
	 * 
	 * Die SQL-Befehle m�ssen alle nach dem ISO-Standard mit einem Semikolon (;)
	 * abgeschlossen sein. Zus�tzlich muss nach dem Semikolon zur Abtrennung des
	 * n�chsten Befehls ein Zeilenumbruch sein.
	 * 
	 * @param sqlFile File-Objekt der Datei, die eingelesen werden soll
	 * @return true, wenn alle Befehle erfolgreich abgearbeitet wurden, false andernfalls
	 * @throws SQLException 
	 */
	public boolean executeSQLFile(File sqlFile) throws SQLException {
		ArrayList<String> befehle = readFile(sqlFile);
		
		boolean erfolgreich = false;
		
		
		// Jeden in der Datei gefundenen Befehl einzeln abarbeiten. Es muss darauf geachtet werden
		// welcher SQL-Befehl ausgef�hrt wird: SELECT oder INSERT/UPDATE/DELETE oder ein anderer
		for (String befehl : befehle) {
			String befehlsart = befehl.substring(0, befehl.indexOf(" "));
			
			erfolgreich = false;
			
			// Entscheidung welcher SQL-Art der Befehl angeh�rt
			switch(befehlsart.toUpperCase()) {
						
			// DQL
			case "SELECT": {
				// werden nicht ausgef�hrt
				erfolgreich = true;
				break;
			}
			
			// DML
			case "INSERT":
			case "UPDATE":
			case "DELETE": {
				try {
					int zeile = executeUpdate(befehl);
					if (zeile >= 0) {
						erfolgreich = true;
					}
				} catch (SQLException e) {
					e.printStackTrace();
					erfolgreich = false;
				}
				
				break;
			}
				
			// DDL, DCL, etc...
			default: {
				try {
					erfolgreich = execute(befehl);
				} catch (SQLException e) {
					e.printStackTrace();
					erfolgreich = false;
				}
				break;
			}
					
			}
			
			// Wenn ein Befehl nicht erfolgreich war
			if (!erfolgreich) {
				break;
			}
			
		}
		
		if (erfolgreich) {
			commit();
		} else {
			rollback();
		}
		
		return erfolgreich;
	}
	
	/**
	 * Gibt das �bergebene ResultSet sauber formatiert als Tabelle in einem String zur�ck.
	 * 
	 * -----------------------
	 * | Spalte 1 | Spalte 2 |
	 * =======================
	 * | Wert 1   | Wert 2   |
	 * | Wert 3   | Wert 4   |
	 * -----------------------
	 * 
	 * @param content Das nicht geschlossene ResultSet
	 * @return formatierter String
	 * @throws SQLException wird geworfen, wenn das ResultSet oder die Datenbankverbindung geschlossen ist
	 */
	public String ausgabe(ResultSet content) throws SQLException {
		return ausgabe(resultSetToArrayList(content));
	}
	
	/**
	 * Gibt die �bergebene ArrayList sauber formatiert als Tabelle in einem String zur�ck.
	 * Der erste Eintrag der ArrayListe muss die Spalten�berschriften beinhalten.
	 * 
	 * -----------------------
	 * | Spalte 1 | Spalte 2 |
	 * =======================
	 * | Wert 1   | Wert 2   |
	 * | Wert 3   | Wert 4   |
	 * -----------------------
	 * 
	 * @param content ArrayList mit String-Arrays. Mindestgr��e ist 1
	 * @return formatierter String oder null
	 */
	public String ausgabe(ArrayList<String[]> content) {
		if (content == null || content.size() < 1) return null;
		
		StringBuilder result = new StringBuilder();
		
		int[] maxSpaltenLaenge = new int[content.get(0).length];
		
		// Maximale Zellenl�ngen herausfinden
		for (String[] zeile : content) {
			for (int i = 0; i < maxSpaltenLaenge.length; i++) {
				maxSpaltenLaenge[i] = max(maxSpaltenLaenge[i], zeile[i].length());
			}
		}
		
		// Gesamtplatzbedarf ermitteln
		int gesamtlaenge = 1;
		for (int i = 0; i < maxSpaltenLaenge.length; i++) {
			gesamtlaenge += maxSpaltenLaenge[i] + 3;
		}
		
		// Horizontaler Trennstrich erstellen
		StringBuilder sbTrennstrich1 = new StringBuilder();
		StringBuilder sbTrennstrich2 = new StringBuilder();
		for (int i = 0; i < gesamtlaenge; i++) {
			sbTrennstrich1.append("-");
			sbTrennstrich2.append("=");
		}
		
		// Ausgabe der einzelnen Zeilen
		result.append(sbTrennstrich1);
		
		for (int j = 0; j < content.size(); j++) {
			result.append("|");
			for (int i = 0; i < maxSpaltenLaenge.length; i++) {
				result.append(String.format(" %-" + maxSpaltenLaenge[i] + "s |", content.get(j)[i]));
			}
			result.append("\n");
			
			if (j == 0) {
				result.append(sbTrennstrich2);		
			}
		}

		result.append(sbTrennstrich1);

		return result.toString();
	}
	
	/**
	 * Gibt das �bergebene ResultSet auf der Konsole sauber formatiert als Tabelle aus.
	 * 
	 * @param content Das nicht geschlossene ResultSet
	 * @return formatierter String
	 * @throws SQLException wird geworfen, wenn das ResultSet oder die Datenbankverbindung geschlossen ist
	 */
	public void ausgabeAufKonsole(ResultSet content) throws SQLException {
		System.out.println(ausgabe(content));
	}
	
	/**
	 * Gibt die �bergebene ArrayList auf der Konsole sauber formatiert als Tabelle aus.
	 * Der erste Eintrag der ArrayListe muss die Spalten�berschriften beinhalten.
	 * 
	 * @param content ArrayList mit String-Arrays. Mindestgr��e ist 1
	 */
	public void ausgabeAufKonsole(ArrayList<String[]> content) {
		System.out.println(ausgabe(content));
	}
	
	/**
	 * Erstellt aus der �bergebenen SQL-Anweisung ein PreparedStatement und gibt es zur�ck
	 * Im Fehlerfall wird null zur�ckgegeben.
	 * 
	 * @param sqlStatement SQL-Statement aus dem ein PreparedStatement gebaut werden soll
	 * @return Das entsprechende Statement oder null
	 * @throwsSQLException wird geworfen, wenn ein Fehler im sqlStatement ist oder die Datenbankverbindung geschlossen ist
	 */
	public PreparedStatement getPreparedStatement(String sqlStatement) throws SQLException {
		if (con != null) {
			PreparedStatement pstmt = con.prepareStatement(sqlStatement);
			pstmtList.add(pstmt);
			return pstmt;
		}
		return null;
	}
	
	
	//-------------------------------------------------------------------------------//
	//                               private Methoden                                //
	//-------------------------------------------------------------------------------//

	/**
	 * Liefert aus der �bergebenen Datei eine Liste mit SQL-Befehlen zur�ck.
	 * Die SQL-Befehle m�ssen alle nach dem ISO-Standard mit einem Semikolon (;)
	 * abgeschlossen sein. Zus�tzlich muss nach dem Semikolon zur Abtrennung des
	 * n�chsten Befehls ein Zeilenumbruch sein.
	 * 
	 * @param sqlFile File-Objekt der Datei, die eingelesen werden soll
	 * @return ArrayList<String> Eine Liste mit den SQL-Befehlen oder null im Fehlerfall
	 */
	private ArrayList<String> readFile(File sqlFile) {
		Scanner in = null;
		ArrayList<String> result = null;
		
		try {
			in = new Scanner(new FileInputStream(sqlFile));
			
			result = new ArrayList<>();
			
			String befehl = "";
			
			// Zeilenweise de Inhalt einlesen
			while (in.hasNextLine()) {
				
				// Solange alles einem Befehl hinzuf�gen, bis das Ende gefunden wurde
				befehl += in.nextLine();
				
				// Wenn die Zeile mit einem ; endet, dann ist das Ende des Befehles gefunden
				if (befehl.endsWith(";")) {
					result.add(befehl.trim());
					befehl = new String("");
				}
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			if (in != null) {
				in.close();
			}
		}
		
		return result;
	}
	
	/**
	 * Diese Funktion geht ein nicht geschlossenes ResultSet durch und stellt alle Informationen
	 * in einer ArrayList bereit. In der ersten Zeile stehen die Spalten�berschriften.
	 * 
	 * @param rs nicht geschlossenes ResultSet
	 * @return ArrayList von String-Arrays mit den Informationen des ResultSets
	 * @throws SQLException wird geworfen, wenn das ResultSet oder die Datenbankverbindung geschlossen ist
	 */
	private ArrayList<String[]> resultSetToArrayList(ResultSet rs) throws SQLException {
		if (rs != null) {
			ArrayList<String[]> result = new ArrayList<>();
			
			// Spalten�berschriften und Anzahl der Spalten abfragen
			int anzahlSpalten = rs.getMetaData().getColumnCount();
			String[] content = new String[anzahlSpalten];
			for (int i = 1; i <= anzahlSpalten; i++) {
				content[i-1] = rs.getMetaData().getColumnLabel(i);
			}
			//result.add(content);
			
			
			// Alle Zeilen durchgehen und auslesen
			while (rs.next()) {
				content = new String[anzahlSpalten];
				for (int i = 1; i <= anzahlSpalten; i++) {
					content[i-1] = rs.getString(i);
					
					// Auf null-Werte testen und korrigieren
					if (content[i-1] == null) {
						content[i-1] = "null";
					}
				}
				result.add(content);
			}
			
			rs.close();
			
			return result;
		}
		return null;
	}
	
	/**
	 * Liefert das Maximum der �bergebenen Parameter
	 * 
	 * @param a Wert 1
	 * @param b Wert2
	 * @return maximum von Wert 1 und Wert 2
	 */
	private int max(int a, int b) {
		return (a > b) ? a : b;
	}
}
