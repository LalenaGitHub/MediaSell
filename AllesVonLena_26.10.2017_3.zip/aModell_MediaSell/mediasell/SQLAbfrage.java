package mediasell;

public class SQLAbfrage<conctante> {
	
	 
	public final static String sqlQueryKassenvorgang = "SELECT * FROM Kassenvorgang;";
	public final static String vKUNDE = "SELECT  kundeNr , vorname, nachname , strasse, hausnr , plz , stadt , email , telefonNr , zahlungsart , status FROM vKunde;";
	public final static String vARTIKEL = "SELECT artikelNr, author, titel, preis, status, bestand, warengruppe FROM vArtikel;";
	public final static String vKKA="SELECT * FROM vKKA";
}
