package mediasell.util;

public class UtilMS {

	
	/**
	 * Methode gibt Status, ausgelesen aus dem String 
	 * @param list
	 * @return boolean true/false
	 */
	public  boolean getStatus(String list) {
		boolean status = false;
		
		if (list.contains("true")) {
			status = true;
		}
		return status;
	}
}
