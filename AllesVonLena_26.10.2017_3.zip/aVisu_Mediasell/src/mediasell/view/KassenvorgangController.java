package mediasell.view;

public class KassenvorgangController {

}
