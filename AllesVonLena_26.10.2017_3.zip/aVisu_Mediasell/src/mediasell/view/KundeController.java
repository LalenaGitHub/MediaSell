package mediasell.view;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import mediasell.datenbank.beans.ArtikelBean;
import mediasell.datenbank.beans.DBMethode;
import mediasell.datenbank.beans.DBMethodeKunde;
import mediasell.model.Artikel;
import mediasell.model.Kassenvorgangliste;
import mediasell.model.Kunde;
import mediasell.model.Kundeliste;
import mediasell.model.Rechnung;

public class KundeController {

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private TableView<Kunde> vKunde;

	@FXML
	private TextField tf_SucheKunde;


    @FXML
    private TableView<Rechnung> vRechnung;

	@FXML
	private Button idAktual;

    @FXML
    private Button btnBestellungen;
    
@FXML
    void RechnungenClick(ActionEvent event) {

    }
	
	@FXML
	void bestellungAnsehen(ActionEvent event) {
	//	vRechnung.refresh();
	//	initTableRechnung();

	}

    	
	
	
	@FXML
	private Button kunden_bearbeiten_button;

	/**
	 * Methode bearbeitet MouseClick und DoubleClick
	 * 
	 * @param event
	 */
	@FXML
	void kundeClick(MouseEvent event) {
		String fensterTitel = "Kunde bearbeiten";
		
		
		zeigeBestellungen();
		
		if (event.getClickCount() > 1) {
			kundenBearbeiten(fensterTitel, false);
			
			

		} else {
			if (vKunde.getSelectionModel().getSelectedItem() == null) {
				event.consume();
				return;
			}
		}
		kunden_bearbeiten_button.setDisable(false);
		 
		btnBestellungen.setDisable(false);
	}

	@FXML
	void kunde_anlegen(ActionEvent event) {
		String fensterTitel = "Kunde anlegen";
		kundenBearbeiten(fensterTitel, true);
	}

	/**
	 * Methode zeigt Dialog-Fenster mit ausgewählten Kunde-Daten zur Korrektur
	 * 
	 * @param event
	 */
	@FXML
	void kunde_bearbeiten(ActionEvent event) {
		String fensterTitel = "Kunde bearbeiten";
		kundenBearbeiten(fensterTitel, false);
	}


	private ObservableList<Kunde> data;
	private FilteredList<Kunde> filteredData;
	Kunde  kundeNrClick;
	
	
	public void kundenBearbeiten(String fensterTitel, boolean fNeu) {
		DBMethodeKunde dbkunde = new DBMethodeKunde();
		// Erstellt einen Dialogfenster
		Dialog<Kunde> dialog = new Dialog<>();
		dialog.setTitle(fensterTitel);

		// Setzt die Buttonform/Art.
		ButtonType loginButtonType = new ButtonType("Speichern", ButtonData.OK_DONE);
		dialog.getDialogPane().getButtonTypes().addAll(loginButtonType, ButtonType.CANCEL);

		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("KundeBearbeiten.fxml"));
		Parent p = null;
		try {
			p = fxmlLoader.load();
		} catch (IOException e) {
			e.printStackTrace();
		}
		KundeBearbeitenController kbc = fxmlLoader.getController();

		System.out.println(vKunde.getSelectionModel().getSelectedItem());

		if (fNeu) {
			Kunde neueKunde = new Kunde("", " ", " ", " ", "plz ", " ", "@", "000-000", 1, true);
			kbc.setKunde(neueKunde);
		} else {

			kbc.setKunde(vKunde.getSelectionModel().getSelectedItem());
			
		
		}

		dialog.getDialogPane().setContent(p);

		// Gibt den neuen Kunden als Result zurück
		dialog.setResultConverter(dialogButton -> {
			if (dialogButton == loginButtonType) {
				return kbc.getKunde();
			}

			return null;
		});

		Optional<Kunde> result = dialog.showAndWait();

		result.ifPresent(kunde -> {

			try {
				if (fNeu) {
					dbkunde.kundeEinfuegen(kunde);
					try {
						aktualisieren();
					} catch (SQLException e) {
			
						e.printStackTrace();
					}
				} else {
					dbkunde.kundeBearbeiten(kunde);
				}
			} catch (ClassNotFoundException e) {

				e.printStackTrace();
			} catch (Exception e) {
		
				e.printStackTrace();
			}
			// ArtikelBean.updateArtikelBestand(kunde.getBestand(),
			// artikel.getArtikelNr());

			vKunde.refresh();
		});
	}

	@FXML
	void suche_starten(ActionEvent event) {
		String gesuchtString = tf_SucheKunde.getText();
		vKunde.setItems(getSearchKundeliste(gesuchtString));
	}

	/**
	 * Methode gibt eine Liste mit gefundenen Kunde zurueck
	 * 
	 * @param gesuchtString
	 * @return ObservableList<Kunde>
	 */
	public static ObservableList<Kunde> getSearchKundeliste(String gesuchtString) {
		ObservableList<Kunde> result = FXCollections.observableArrayList();

		ObservableList<Kunde> alleKundeListe = Kundeliste.kundeListe;
		String artikelTitel = "";
		String autor = "";
		String kundeNr = "";

		gesuchtString = gesuchtString.toLowerCase();

		for (Kunde kunde : alleKundeListe) {
			artikelTitel = kunde.getVorname().toLowerCase();
			autor = kunde.getNachname().toLowerCase();
			kundeNr = Integer.toString(kunde.getKundeNr()).toLowerCase();

			if ((artikelTitel.contains(gesuchtString))
					|| (autor.contains(gesuchtString) || (kundeNr.contains(gesuchtString)))) {
				result.add(kunde);
			}

		}

		return result;
	}

	@FXML
	void aktualisieren(ActionEvent event) throws SQLException {
		aktualisieren();

	}

	void aktualisieren() throws SQLException {
//		DBMethode dbKunde = new DBMethode();
//		dbKunde.listeAktualisieren();
//		vKunde.setItems(Kundeliste.kundeListe);
		vKunde.refresh();
	}

	@FXML
	void alleKunden_anzeigen(ActionEvent event) {

	}

	@FXML
	void initialize() {
	
	        assert vKunde != null : "fx:id=\"vKunde\" was not injected: check your FXML file 'Kunde.fxml'.";
	        assert tf_SucheKunde != null : "fx:id=\"tf_SucheKunde\" was not injected: check your FXML file 'Kunde.fxml'.";
	        assert kunden_bearbeiten_button != null : "fx:id=\"kunden_bearbeiten_button\" was not injected: check your FXML file 'Kunde.fxml'.";
	        assert btnBestellungen != null : "fx:id=\"btnBestellungen\" was not injected: check your FXML file 'Kunde.fxml'.";
	        assert idAktual != null : "fx:id=\"idAktual\" was not injected: check your FXML file 'Kunde.fxml'.";
	        assert vRechnung != null : "fx:id=\"vRechnung\" was not injected: check your FXML file 'Kunde.fxml'.";

	   

		initTable();
		initTableRechnung();

		kunden_bearbeiten_button.setDisable(true);
		btnBestellungen.setDisable(true);
		btnBestellungen.setVisible(false);

	}

	
	
	
	private void initTable() {
		// Spalten erstellen
		TableColumn<Kunde, String> tc1 = new TableColumn<>("KNr");
		TableColumn<Kunde, String> tc2 = new TableColumn<>("Vorname");
		TableColumn<Kunde, String> tc3 = new TableColumn<>("Nachname");
		TableColumn<Kunde, String> tc4 = new TableColumn<>("Strasse");
		TableColumn<Kunde, String> tc5 = new TableColumn<>("HaunsNr");
		TableColumn<Kunde, String> tc6 = new TableColumn<>("Plz");
		TableColumn<Kunde, String> tc7 = new TableColumn<>("Stadt");
		TableColumn<Kunde, String> tc8 = new TableColumn<>("e-mail");
		TableColumn<Kunde, String> tc9 = new TableColumn<>("telefonNr");
		TableColumn<Kunde, String> tc10 = new TableColumn<>("Status");

		// Zuordnung Werte <-> Model
		tc1.setCellValueFactory(new PropertyValueFactory<>("kundeNr"));
		tc2.setCellValueFactory(new PropertyValueFactory<>("vorname"));
		tc3.setCellValueFactory(new PropertyValueFactory<>("nachname"));
		tc4.setCellValueFactory(new PropertyValueFactory<>("strasse"));
		tc5.setCellValueFactory(new PropertyValueFactory<>("hausnr"));
		tc6.setCellValueFactory(new PropertyValueFactory<>("plz"));
		tc7.setCellValueFactory(new PropertyValueFactory<>("stadt"));
		tc8.setCellValueFactory(new PropertyValueFactory<>("email"));
		tc9.setCellValueFactory(new PropertyValueFactory<>("telefonNr"));
		tc10.setCellValueFactory(new PropertyValueFactory<>("status"));

		// Spalten hinzufügen
		vKunde.getColumns().add(tc1);
		vKunde.getColumns().add(tc2);
		vKunde.getColumns().add(tc3);
		vKunde.getColumns().add(tc4);
		vKunde.getColumns().add(tc5);
		vKunde.getColumns().add(tc6);
		vKunde.getColumns().add(tc7);
		vKunde.getColumns().add(tc8);
		vKunde.getColumns().add(tc9);
		vKunde.getColumns().add(tc10);

		try {
			data = Kundeliste.kundeListe;

			// filteredData = new FilteredList<>(data, p -> true);
			// SortedList<Artikel> sortedData = new SortedList<>(filteredData);
			// sortedData.comparatorProperty().bind(vKunde.comparatorProperty());
			// vKunde.setItems(sortedData);

		} catch (Exception e) {
			// data = (ArrayList<Kunde>) FXCollections.observableArrayList();
			// vKunde.setItems(data);
			// e.printStackTrace();
		}

		vKunde.setItems(data);

	}


	
	
	private ObservableList<Rechnung> dataRechnung;
 
	
	 private void initTableRechnung() {
		 //vRechnung.getItems().clear();		 
		 
		 
			// String autor, String titel, double preis, boolean status, int
					// bestand, int warengruppe

			// Spalten erstellen (�berschirften)
			TableColumn<Rechnung, String> tc1 = new TableColumn<>("KassenvorgangID");
			TableColumn<Rechnung, String> tc2 = new TableColumn<>("Datum");
			TableColumn<Rechnung, String> tc3 = new TableColumn<>("KundeId");
			//TableColumn<Rechnung, String> tc4 = new TableColumn<>("Kunde");

			// Zuordnung Werte <-> Model
			tc1.setCellValueFactory(new PropertyValueFactory<>("kassenvorgangID"));
			tc2.setCellValueFactory(new PropertyValueFactory<>("datum"));
			tc3.setCellValueFactory(new PropertyValueFactory<>("kundeNr"));
			//tc3.setCellValueFactory(new PropertyValueFactory<>("kundeNr"));

			// Spalten hinzuf�gen
			
			vRechnung.getColumns().add(tc1);
			vRechnung.getColumns().add(tc2);
			vRechnung.getColumns().add(tc3);
	//		vRechnungen.getColumns().add(tc4);

			//dataRechnung = Kassenvorgangliste.kassenvorgangListe;
			
			// zeigeBestellungen ();
		}
	 
	 
	 void zeigeBestellungen () {
		 vRechnung.getItems().clear();	
		 
			Kunde kunde = vKunde.getSelectionModel().getSelectedItem();
		 
			dataRechnung = 	kunde.sucheRechnung ();

			vRechnung.setItems(dataRechnung);
	 }
	
}
