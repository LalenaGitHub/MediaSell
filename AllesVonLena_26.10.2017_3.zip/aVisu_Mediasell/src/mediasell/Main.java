package mediasell;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import mediasell.datenbank.Datenbank;
import mediasell.datenbank.beans.DBMethode;

public class Main extends Application{
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		try {
			AnchorPane root = FXMLLoader.load(getClass().getResource("view/MenueGUI.fxml"));
			Scene scene = new Scene(root);
			primaryStage.setTitle("MediaSell Plattform");
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	public static void main(String[] args) throws Exception {
		DBMethode init = new DBMethode();
		init.ini();
		Datenbank.getInstance();
		launch(args);
	}
	
}
