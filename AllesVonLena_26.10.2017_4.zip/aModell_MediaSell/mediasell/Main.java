package mediasell;


import mediasell.datenbank.beans.DBMethode;

public class Main {

	public static void main(String[] args) throws Exception {
 
			DBMethode init = new DBMethode();
			init.ini();
			
			
			
			
//			System.out.println("Einlesen der SQL-Datei 'supermarkt.sqlite': " + sqlite.executeQuery("SELECT * FROM artikel;"));
			//System.out.println(sqlite.ausgabe(sqlite.executeQuery("SELECT * FROM Artikel;")));
			//System.out.println(sqlite.ausgabe(sqlite.executeQuery("SELECT * FROM Kunde;")));
//			String vorname = "John A.";
//			String nachname = "Dr. Zoidberg";
//			String strasse = "";
//			String hausnr="";
//			String plz="";
//			String stadt="Dekapod-10";
//			String email="";
//			String telefonNr ="";
//			int zahlungsart=1;
//			boolean status=false;
			
			
//			Kunde neuKunde = new Kunde( vorname,  nachname,  strasse,  hausnr,  plz,  stadt,  email,
//					 telefonNr,  zahlungsart,  status);
//			
//			
//			Kunde testKunde = new Kunde();
//			testKunde = testKunde.getKundeFromListe(1);
//			
//			System.out.println(" KundeNr : " +  testKunde.getNachname()) ;
//			
//			System.out.println(" status : " +  testKunde.pruefeKundenstatus() );
			
			
//			Artikel testArtikel = new Artikel();
//			testArtikel = testArtikel.getArtikelFromListe(5);
//			
//			System.out.println(" Artikel Nr: " +  testArtikel.getArtikelNr()) ;
//			
//			System.out.println(" status : " +  testArtikel.artikelStatusPruefen() );
			
		//	testArtikel.bestandErhoehen(100, sqlite);
			
			
		//	 neuKunde.kundeEinfuegen(sqlite);
//			 Kunde kunde = new Kunde(17, 7);
//			 kunde.kundeMakeAktiv(sqlite);
//			 kunde.kundeBearbeiten(sqlite);
			
			
			
 
			
			
//			kunde.zeigeBestellung(kunde);
			
		

		
		//######### was ist die Datenbank ".sql" oder ".sqlite" in .sqlite steht bin�rerstrom in .sql stehen alle Informationen �ber die Datenbank ############
		
	}


}
