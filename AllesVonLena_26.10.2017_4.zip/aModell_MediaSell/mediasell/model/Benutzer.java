package mediasell.model;


public class Benutzer {
	String benutzername;
	String passwort;
	
	public Benutzer(String benutzername, String passwort) {
		this.benutzername = benutzername;
		this.passwort = passwort;
	}
	
	/**
	 * liest den gespeicherten Passwort aus der Datenbank aus
	 * @return
	 */
	public String getPasswort()
	{
		
		return "";
	}
	
	/**
	 * prueft ob das eingebene Passwort mit dem gespeicherten Passwort aus der Datenbank �bereinstimmt
	 * und gibt je nachdem ob das Passwort stimmt true oder false zur�ck
	 * @param passwort
	 * @param eingegebenePasswort
	 * @return
	 */
	public boolean pruefePasswort(String passwort, String eingegebenePasswort)
	{
		
		return false;
	}
	
	
	
	
	
	
	
}
