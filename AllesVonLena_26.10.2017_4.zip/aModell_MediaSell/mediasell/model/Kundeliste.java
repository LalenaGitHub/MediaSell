package mediasell.model;

import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Kundeliste {

	
//	public static ArrayList<Kunde> kundeListe;
 
	public static	ObservableList<Kunde> kundeListe = FXCollections.observableArrayList();
	
	/**
	 * Methode sucht in der Liste nach einen bestimten Kunde anhang einer
	 * KundeNr
	 * 
	 * @param kundeNr
	 * @return kunde Kunde
	 */
	public static Kunde getKundeFromListe(int kundeNr) {
		ObservableList<Kunde> alleKundeListe = kundeListe;
 
		for (Kunde kunde : alleKundeListe) {
			if (kunde.getKundeNr() == kundeNr) {
				return kunde;
			}
		}
		return null;
	}
	
	


	
	
	/**
	 * Methode sucht  alle Kunden die DB nach einem Suchwort
	 * 
	 * @param suchWort
	 * @return Liste von Kunden
	 */
	public ArrayList<Kunde> sucheKunde(String suchWort) {

		ArrayList<Kunde> listGefundenKunde = new ArrayList<Kunde>();

		for (Kunde kunde : kundeListe) {
			// System.out.println(rechnung.toString());

			if (String.valueOf(kunde.getKundeNr()).contains(suchWort)) {
				listGefundenKunde.add(kunde);
			}
		}

		return listGefundenKunde;
	}






	public static ObservableList<Kunde> getKundeListe() {
		ObservableList<Kunde> kListe = kundeListe;
		return kListe;
	}




}
