package mediasell.model;

public class Kassenvorgang {


	public boolean abschliessendeBestellung() {
		
		// TODO nicht fertig! 
		return false;
	}

	/**
	 * exportiert die Rechnung in eine externe Zeichenbasiertedatei
	 */
	public boolean bestellungDrucken() {
		return false;
	}




	// TODO nicht fertig
	public String getToString(Kassenvorgang kassenvorgang) {

		return "";

	}

}
