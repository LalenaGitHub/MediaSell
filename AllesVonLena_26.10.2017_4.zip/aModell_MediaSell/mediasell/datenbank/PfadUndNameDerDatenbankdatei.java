package mediasell.datenbank;

public class PfadUndNameDerDatenbankdatei {

	
// public static String  dbPfadUndName =	"Z:\\MEDIASELL_DB\\MediaSell.sqlite" ;
	public static String  dbPfadUndName =	"Z:\\MediaSell.sqlite" ;
	




}
