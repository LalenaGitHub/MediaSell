package mediasell.datenbank.beans;

/**
 * @author
 * 
 */
public class Warnungen {

	String warnungUnplausibeleZugebuchteMenge = "Die zugebuchte Menge darf nicht negativ sein!";
	String warnungUnplausibeleBestandMenge = "Bestand-Menge ist unplausibel!";
	String warnungUnplausibeleNeueMenge = "Neuer Menge-Wert ist unplausibel!";
	String warnungUnplausibeleAusgebuchteMenge = "Die ausgebuchte Menge darf nicht negativ sein!";
	String warnungUnplausibeleKundeNr = "KundeNr ist unplausibel!";
	String warnungunplausibeleKassenvorgangID = "KassenvorgangID ist unplausibl!";

	public String negativeZugebuchteMenge(int zugebuchteMenge) {
		return warnungUnplausibeleZugebuchteMenge + " [" + zugebuchteMenge
				+ "]";
	}

	public String unplausibeleBestandMenge(int bestand) {
		return warnungUnplausibeleBestandMenge + " [" + bestand + "]";
	}

	public String unplausibeleNeueMenge(int bestand, int zugebuchteMenge,
			int neueMenge) {
		return warnungUnplausibeleNeueMenge + " Bestand [" + bestand
				+ "], zugebuchte Menge [" + zugebuchteMenge + "], neue Menge ["
				+ neueMenge + "]";
	}

	public String negativeAusgebuchteMenge(int ausgebuchteMenge) {

		return warnungUnplausibeleAusgebuchteMenge + " [" + ausgebuchteMenge
				+ "]";
	}

	public String unplausibeleKundeNr(int neueKundeNr) {
		return warnungUnplausibeleKundeNr + " [" + neueKundeNr + "]";
	}

	public String unplausibeleKassenvorgangID(int kassenvorgangID) {

		return warnungunplausibeleKassenvorgangID + " [" + kassenvorgangID
				+ "]";

	}

 
}
