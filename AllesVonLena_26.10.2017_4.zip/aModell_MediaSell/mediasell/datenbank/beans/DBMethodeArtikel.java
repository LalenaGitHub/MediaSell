package mediasell.datenbank.beans;

import java.sql.SQLException;

import mediasell.datenbank.Datenbank;
import mediasell.model.Artikel;

public class DBMethodeArtikel {
Warnungen warnung = new Warnungen();
DBMethode dbM = new DBMethode();	
	
	/**
	 * Methode reduziert die vorhandene Artikelmenge um eins
	 * 
	 * @param ausgebuchteMenge int
	 * @param artikel Artikel	 
	 * @return neue Menge int
	 * @throws Exception 
	 */
	public int bestandReduzieren( int ausgebuchteMenge, Artikel artikel)
			throws Exception {

		int neueMenge = 0;
		
		neueMenge =	artikel.getBestand() - ausgebuchteMenge;

		if (!checkMenge(ausgebuchteMenge)) {
			throw new Exception(warnung.negativeAusgebuchteMenge(ausgebuchteMenge));
		} else if (!checkMenge(artikel.getBestand())) {
			throw new Exception(warnung.unplausibeleBestandMenge(artikel.getBestand()));
		}
		else if (!checkMenge(neueMenge)) {
				throw new Exception(warnung.unplausibeleNeueMenge(artikel.getBestand(), ausgebuchteMenge, neueMenge));
				
			}
	 

		else {
			String update = "UPDATE \"Artikel\" SET " + "bestand = \" " + neueMenge
					+ " \" WHERE \"artikelNr\" = " + artikel.getArtikelNr();

			Datenbank.getInstance().executeUpdate(update);
			dbM.listeAktualisieren ();
		}

		return neueMenge;
	}

	/**
	 * Methode erhöht die vorhandene Artikelmenge um eins
	 * 
	 * @param zugebuchteMenge
	 * @param artikel Artikel
	 * @return int neueMenge
	 * @throws SQLException
	 */
	public int bestandErhoehen(int zugebuchteMenge, Artikel artikel)
			throws SQLException, Exception {
		String update = "";
		int neueMenge = -1;

		neueMenge = artikel.getBestand() + zugebuchteMenge;
		
		if (!checkMenge(zugebuchteMenge)) {
			throw new Exception(warnung.negativeZugebuchteMenge(zugebuchteMenge));
		} else if (!checkMenge(artikel.getBestand())) {
			throw new Exception(warnung.unplausibeleBestandMenge(artikel.getBestand()));
		}
		else if (!checkMenge(neueMenge)) {
				throw new Exception(warnung.unplausibeleNeueMenge(artikel.getBestand(), zugebuchteMenge, neueMenge));
			}
	 

		else {
			update = "UPDATE \"Artikel\" SET " + "bestand = \" " + neueMenge
					+ " \" WHERE \"artikelNr\" = " + artikel.getArtikelNr();

			Datenbank.getInstance().executeUpdate(update);
		}

		return neueMenge;

	}

	/**
	 * Methode prüft Plausibilität der Menge
	 * 
	 * @param menge
	 *            int
	 * @return boolean geignet/nicht geeignet
	 */
	private boolean checkMenge(int menge) {
		boolean result = false;

		if (menge >= 0) {
			result = true;
		}
		return result;
	}

	public void setStatusAktiv(Artikel artikel) throws Exception {
		String update = "";
       
		if (!checkMenge(artikel.getBestand())) {
			throw new Exception(warnung.unplausibeleBestandMenge(artikel.getBestand()));
		}

	 

		else {
			update = "UPDATE \"Artikel\" SET " + "status = \"true\" "
					+ "  WHERE \"artikelNr\" = " + artikel.getArtikelNr();

			Datenbank.getInstance().executeUpdate(update);
		}


		
	}

}
