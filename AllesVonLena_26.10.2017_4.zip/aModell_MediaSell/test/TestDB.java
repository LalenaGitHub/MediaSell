package test;
import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.ArrayList;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import mediasell.datenbank.beans.ArtikelBean;
import mediasell.datenbank.beans.DBMethode;
import mediasell.datenbank.beans.DBMethodeArtikel;
import mediasell.datenbank.beans.DBMethodeKunde;
import mediasell.datenbank.beans.DBMethodeRechnung;
import mediasell.datenbank.verbindung.SQLiteDatenbankverbindung;
import mediasell.model.Artikel;

import mediasell.model.Kassenvorgang;
import mediasell.model.Kassenvorgangliste;
import mediasell.model.Kunde;
import mediasell.model.Kundeliste;
import mediasell.model.Position;
import mediasell.model.Rechnung;

public class TestDB {

	@Before
	public void inittial() throws Exception {
		DBMethode init = new DBMethode();
		init.ini();
	
	}
	
	 
	@Test
	public void testRechnung () throws Exception, SQLException, Exception {
		DBMethodeRechnung  dbRechnung = new DBMethodeRechnung();
		
//		Rechnung r = new Rechnung();
//		
//		for (Rechnung rechnung :  Kassenvorgangliste.kassenvorgangListe) { 
//		
//			rechnung.getAnzahlPositionen();
//			
//		}
		
		
		
		
//		int kassenvorgangID = 6;
//		int artikelNr = 3;
//		Position p1 = new Position ( kassenvorgangID,  artikelNr,  3);
//		artikelNr = 4;
//		Position p2 = new Position (kassenvorgangID,  artikelNr,  4);
//		
//		ArrayList<Position> gesamteBestellung = new ArrayList<Position>();
//		gesamteBestellung.add(p1);
//		gesamteBestellung.add(p2);
//		 
// 
//		 boolean storno = false;
//		 int kundeNr = 4;
//		
//		 String datum = "";
//		
//		Rechnung rechnung = new Rechnung(gesamteBestellung, kassenvorgangID, datum, storno, kundeNr);
//		dbRechnung.rechnungEinfuegen(rechnung);
//		
		
	}
	
	@Ignore
	@Test 
	public void testKunde() throws ClassNotFoundException, SQLException, Exception {
		//  Kunde leer
	//	Kunde kunde = new Kunde ();
		DBMethodeKunde dbKunde = new DBMethodeKunde();
		//System.out.println(kunde.toString());
	//	assertEquals("Kunde leer", kunde.getKundeNr(), -1);
		
		// Kunde aus der Liste
		Kunde bine = Kundeliste.getKundeFromListe(6);
		//System.out.println(bine.toString());
		assertEquals("Kunde leer", bine.getKundeNr(), 6);
		
		
		// Kunde neu
		String vorname = "John A.";
		String nachname = "Dr. Zoidberg";
		String strasse = "";
		String hausnr="10";
		String plz="-XFF-";
		String stadt="Dekapod";
		String email="";
		String telefonNr ="";
		int zahlungsart=1;
		boolean status=false;
		
		// Kunde nur als Objekt erstellen, ohne KundeNr, wird später automatisch generiert  
		Kunde john = new Kunde( vorname,  nachname,  strasse,  hausnr,  plz,  stadt,  email,
				 telefonNr,  zahlungsart,  status);
		
		System.out.println("Bevor einfügen DB " + john.toString());
		
		// Kunde in DB speichern 
		 
		//	int neueKundeNr =dbKunde.kundeEinfuegen(john);
		//	john = john.getKundeFromListe(neueKundeNr);
		//    System.out.println("danach " + john.toString());
		
		 // Suchen nicht existierenden Kunde
		    
//		    Kunde phantom = new Kunde();
//		    phantom = phantom.getKundeFromListe(56);
//		   
//		    int neueKundeNr = dbKunde.kundeEinfuegen(phantom);
//		    phantom = phantom.getKundeFromListe(neueKundeNr);
//		    System.out.println("Phantom " + phantom.toString());
//		    neueKundeNr = dbKunde.kundeBearbeiten(phantom);
//		    phantom = phantom.getKundeFromListe(neueKundeNr);
//		    System.out.println("Phantom Edit" + phantom.toString());
		    
			Kassenvorgang kasssenvorgang = new Kassenvorgang();
			System.out.println("Rechnungen gefunden: \n");
			
			DBMethodeRechnung dbRechnung = new DBMethodeRechnung();
			
			for (Rechnung rechnung : Kassenvorgangliste.kassenvorgangListe) {
		 	 	System.out.println(rechnung.toString());
				
 				if (rechnung.getKassenvorgangID() == 1){
 					dbRechnung.setStorno(rechnung);
 					
 				}
	 	//	System.out.println(rechnung.toString());	
				
			}
			
			
//			for (Rechnung rechnung : kasssenvorgang.rechnungSuchen ("Jogi")) {
//			//	System.out.println(rechnung.toString());
//				
//				if (rechnung.getKassenvorgangID() == 1){
//					dbRechnung.setStorno(rechnung);
//					
//				}
//			System.out.println(rechnung.toString());	
//				
//			}
			
		
	}
	
 
	@Test 
	public void testArtikel() throws SQLException   {
		
		DBMethodeArtikel dbArtikel = new DBMethodeArtikel();
		
	//	Artikel artikel = new Artikel ();
	//	System.out.println(artikel.toString());
		
 
		
		Artikel buch = ArtikelBean.getArtikel(1);
		
		
		System.out.println(buch.toString());
		
//		assertEquals("Menge Leere Artikel", artikel.getMenge(), -1);
//		assertEquals("Menge Leere Artikel", artikel.artikelStatusPruefen(), false);
//
//	 	//assertEquals("Menge Buch", buch.getMenge(), 19);
//		assertEquals("Menge Buch", buch.artikelStatusPruefen(), false);
//		int alteMenge = buch.getMenge();
		try {
//			assertEquals("Menge", dbArtikel.bestandErhoehen(-6, artikel), 0);
//			assertEquals("Menge", dbArtikel.bestandErhoehen(0, artikel), 0);
//			assertEquals("Menge", dbArtikel.bestandErhoehen(3, artikel), 0);			
			
//		 	assertEquals("Menge", dbArtikel.bestandErhoehen(6, buch), alteMenge+6);
//			assertEquals("Menge", dbArtikel.bestandErhoehen(0, buch), alteMenge);
//			assertEquals("Menge", dbArtikel.bestandErhoehen(-3, buch), 0);

//		 	assertEquals("Menge", dbArtikel.bestandReduzieren(5, buch), alteMenge-5);
//			assertEquals("Menge", dbArtikel.bestandReduzieren(0, buch), alteMenge);
			//assertEquals("Menge", dbArtikel.bestandReduzieren(-1, buch), 0);
			

			
		} catch (Exception e) {
			 
			e.printStackTrace();
		}
 
		
	}

	 

}
