package mediasell.view;

import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import mediasell.datenbank.beans.ArtikelBean;
import mediasell.datenbank.beans.DBMethodeRechnung;
import mediasell.model.Artikel;
import mediasell.model.Kassenvorgangliste;
import mediasell.model.Kunde;
import mediasell.model.Kundeliste;
import mediasell.model.Position;
import mediasell.model.Rechnung;


public class KassenvorgangController {

	// das aktuelle Datum
	LocalDate aktuellesDatum = LocalDate.now();
	
    @FXML
    private ResourceBundle resources;
    @FXML
    private URL location;
    @FXML
    private Button rechnungBtn;
    @FXML
    private Button verkaufenBtn;
    @FXML
    private TextField tfArtikel;
    @FXML
    private Button kundeHinzufuegenBtn;
    @FXML
    private Button inWarenkorbBtn;
    @FXML
    private TextArea kassenbonTextArea;
    @FXML
    private TextField tfKundennummer;
    @FXML
    private TableView<Rechnung> kassenbonTableView;
    @FXML
    private TextField suchfeldKassenbon;
    
	private ObservableList<Rechnung> data;
	private FilteredList<Rechnung> filteredData;
    ObservableList<Position> gesamteBestellung = FXCollections.observableArrayList();
    
   int kundeNr =-1;

    /**
     * legt ein aktuelles Datum in dem Kassenbon an
     * F�gt ein Artikel dem Kassenbon hinzu
     * @param event
     * @throws SQLException 
     */
    @FXML
    void inDenWarenkorb(ActionEvent event) throws SQLException {
    	try {
    		if(pruefeObArtikelVorhanden(Integer.parseInt(tfArtikel.getText())) == true){
    			kassenbonTextArea.appendText(passendenArtikelHeraussuchen(Integer.parseInt(tfArtikel.getText())));
    			kassenbonTextArea.appendText("\n");
    	    	verkaufenBtn.setDisable(false);
    	    	positionErstellen(Integer.parseInt(tfArtikel.getText()));
    		}
	    } catch (NumberFormatException fehler) {
	    	tfArtikel.setText(""); 	 //leert den Artikeltextboxinhalt
	    	
	    }
    	tfArtikel.setText("");
    }
    
    /**
     * F�gt einen Kunden der Rechnung hinzu
     * @param event
     */
    @FXML
    void kundeHinzufuegen(ActionEvent event) {
    	try {
    		if(pruefeObKundeVorhanden(Integer.parseInt(tfKundennummer.getText())) == true){
    			kassenbonTextArea.appendText(passendenKundenHeraussuchen(Integer.parseInt(tfKundennummer.getText())));
    			kassenbonTextArea.appendText("\n");
    			inWarenkorbBtn.setDisable(false);
    			kundeHinzufuegenBtn.setDisable(true);
    			tfKundennummer.setDisable(true);
    			tfArtikel.setDisable(false);
    			
    			kundeNr = Integer.parseInt(tfKundennummer.getText());
    		}
	    } catch (NumberFormatException fehler) {
	    	tfKundennummer.setText(""); 	 //leert den Kundentextboxinhalt
	    	
	    }
    	tfKundennummer.setText("");
    }
    
    private String datumFormatieren(LocalDate ld)
    {
    	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		return ld.format(dtf);
    }
    
    boolean pruefeObArtikelVorhanden(int artikelNr)
    {
    	//pr�fen zu welchem Artikel die ArtikelNr geh�rt und den Artikel dem kassenbonTextArea hinzuf�gen
    	return true;
    }
    
    boolean pruefeObKundeVorhanden(int artikelNr)
    {
    	//pr�fen zu welchem Artikel die ArtikelNr geh�rt und den Artikel dem kassenbonTextArea hinzuf�gen
    	return true;
    }
    
    /**
     * Sucht nach einem Artikel in der Artikelliste und
     * gibt den gefunden Artikel in formatiertem String zur�ck
     * @param artikelNr
     * @return
     * @throws SQLException
     */
    private String passendenArtikelHeraussuchen(int artikelNr) throws SQLException
    {
    	for (Artikel artikel : ArtikelBean.getArtikelliste())
    	{
    		if (artikel.getArtikelNr() == artikelNr)
    		{
    			return artikel.getArtikelNr() + " " + artikel.getAutor() + " " + artikel.getTitel() + " " + artikel.getPreis(); 
    		}
    	}
		return "Artikel nicht gefunden!";
    }
    
    /**
     * Sucht nach einem Kunde in der Kundeliste und
     * gibt den gefundenen Kunden in formatiertem String zur�ck
     * @param artikelNr
     * @return
     * @throws SQLException
     */
    private String passendenKundenHeraussuchen(int kundenNr)
    {
    	for (Kunde kunde : Kundeliste.kundeListe)
    	{
    		if (kunde.getKundeNr() == kundenNr)
    		{
    			return kunde.getKundeNr() + " " + kunde.getVorname() + " " + kunde.getNachname(); 
    		}
    	}
		return "Kunde nicht gefunden!";
    }

    /**
     * Verwirft Die Informationen aus dem Kassenbon
     * @param event
     */
    @FXML
    void neuerKassenbon(ActionEvent event) {
    	verkaufenBtn.setDisable(true);
    	rechnungBtn.setDisable(true);
    	tfArtikel.setDisable(true);
    	inWarenkorbBtn.setDisable(true);
    	kundeHinzufuegenBtn.setDisable(false);
    	tfKundennummer.setDisable(false);
    	kassenbonTextArea.clear();
    }

    /**
     * erstellt eine Position aus artikelNr und Anzahl
     * f�gt die einzelnen Positionen der Liste hinzu
     * @param artikelNr
     */
    private void positionErstellen(int artikelNr)
    {
    	Position position = new Position(artikelNr, 1);
    	gesamteBestellung.add(position);
    }
    
    /**
     * Sschreibt den Kassenvorgang bzw. Kassenbohn in die Datenbank
     * @param event
     * @throws Exception 
     * @throws SQLException 
     * @throws ClassNotFoundException 
     */
    @FXML
    void verkaufen(ActionEvent event) throws ClassNotFoundException, SQLException, Exception {
    	datumDemkassenbonHinzufuegen();
    	verkaufenBtn.setDisable(true);
    	rechnungBtn.setDisable(false);
    	tfArtikel.setDisable(true);
    	inWarenkorbBtn.setDisable(true);
    	
    	//TODO Rechnung schreiben
    	Rechnung rechnung = new Rechnung(gesamteBestellung, 0, datumFormatieren(aktuellesDatum), false, kundeNr);
    	
//    	ObservableList<Position> gesamteBestellung, int kassenvorgangID, String datum, boolean storno, int kundeNr
    	
    	DBMethodeRechnung db = new DBMethodeRechnung();
    	db.rechnungEinfuegen(rechnung);
    }
    

    
    
    
    
    /**
     * Druckt den Kassenbohn in eine externe zeichenbasierte Datei
     * @param event
     */
    @FXML
    void rechnungErstellen(ActionEvent event) {
    	verkaufenBtn.setDisable(true);
    	rechnungBtn.setDisable(true);
    }
    
    /**
     * Durchsucht alle Kassenvorg�nge
     * @param event
     */
    @FXML
    void kassenvorgangSuchen(ActionEvent event) {
    	
    }
    
    public void kNrTF_aNrTF_Deaktivieren()
    {
    	tfArtikel.setDisable(false);
    	tfKundennummer.setDisable(false);
    }
    
    public void kNrTF_aNrTF_Aktivieren()
    {
    	tfArtikel.setDisable(false);
    	tfKundennummer.setDisable(false);
    }

    /**
     * H�ngt ein aktuelles Datum im Kassenbon hinten dran
     */
    public void datumDemkassenbonHinzufuegen()
    {
    	kassenbonTextArea.appendText(datumFormatieren(aktuellesDatum));
    }

    @FXML
    void initialize() {
        assert tfArtikel != null : "fx:id=\"tfArtikel\" was not injected: check your FXML file 'Kassenvorgang.fxml'.";
        assert tfKundennummer != null : "fx:id=\"tfKundennummer\" was not injected: check your FXML file 'Kassenvorgang.fxml'.";
        assert kassenbonTextArea != null : "fx:id=\"kassenbonTextArea\" was not injected: check your FXML file 'Kassenvorgang.fxml'.";
        assert rechnungBtn != null : "fx:id=\"rechnungBtn\" was not injected: check your FXML file 'Kassenvorgang.fxml'.";
        assert verkaufenBtn != null : "fx:id=\"verkaufenBtn\" was not injected: check your FXML file 'Kassenvorgang.fxml'.";
        assert inWarenkorbBtn != null : "fx:id=\"inWarenkorbBtn\" was not injected: check your FXML file 'Kassenvorgang.fxml'.";
        assert kundeHinzufuegenBtn != null : "fx:id=\"kundeHinzufuegenBtn\" was not injected: check your FXML file 'Kassenvorgang.fxml'.";
        assert kassenbonTableView != null : "fx:id=\"kassenbonTableView\" was not injected: check your FXML file 'Kassenvorgang.fxml'.";
        assert suchfeldKassenbon != null : "fx:id=\"suchfeldKassenbon\" was not injected: check your FXML file 'Kassenvorgang.fxml'.";
        
        initTable();
        suchfeldKassenbon.textProperty().addListener((observable, oldValue, newValue)  -> sucheKassenbon());
    }
    
    //##############################################################################################################################
    //####################### Storno Spalte in der Datenbank muss noch gel�scht werden #############################################
    //##############################################################################################################################
    
    private void initTable() {
		// String autor, String titel, double preis, boolean status, int
				// bestand, int warengruppe

		// Spalten erstellen (�berschirften)
		TableColumn<Rechnung, String> tc1 = new TableColumn<>("KvNr");
		TableColumn<Rechnung, String> tc2 = new TableColumn<>("Datum");
		TableColumn<Rechnung, String> tc3 = new TableColumn<>("Gesamtpreis");
		TableColumn<Rechnung, String> tc4 = new TableColumn<>("Kunde");

		// Zuordnung Werte <-> Model
		tc1.setCellValueFactory(new PropertyValueFactory<>("kassenvorgangID"));
		tc2.setCellValueFactory(new PropertyValueFactory<>("datum"));
		tc3.setCellValueFactory(new PropertyValueFactory<>("gesamtpreis"));
		tc3.setCellValueFactory(new PropertyValueFactory<>("kundeNr"));

		// Spalten hinzuf�gen
		
		kassenbonTableView.getColumns().add(tc1);
		kassenbonTableView.getColumns().add(tc2);
		kassenbonTableView.getColumns().add(tc3);
		kassenbonTableView.getColumns().add(tc4);

		try {
			data = Kassenvorgangliste.kassenvorgangListe;

		} catch (Exception e) {
			// data = (ArrayList<Kunde>) FXCollections.observableArrayList();
			// vKunde.setItems(data);
			// e.printStackTrace();
		}

		kassenbonTableView.setItems(data);
	}
    
    
    /**
   	 * Methode sucht Artikel nach einem SuchWort
   	 * 
   	 * @param event
   	 */
   	void sucheKassenbon() {
   				
   		filteredData.setPredicate((Rechnung rechnung) -> {
   			boolean result = false;
   			
   			String gesuchtString = suchfeldKassenbon.getText();
   			if (gesuchtString.isEmpty()) {
   				result = true;
   			} else {
   				result = result || Integer.toString(rechnung.getKassenvorgangID()).contains(gesuchtString);
   				result = result || rechnung.getDatum().contains(gesuchtString);
   				result = result || Integer.toString(rechnung.getKundeNr()).contains(gesuchtString);
   			}
   			
   			return result;
   		});
   	}

    
    
}
