package mediasell.view;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Optional;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import mediasell.datenbank.beans.ArtikelBean;
import mediasell.datenbank.beans.DBMethode;
import mediasell.model.Artikel;

public class ArtikelController {



	@FXML
	private TextField suchfeldArtikel;

	@FXML
	private TableView<?> tabelleSuchemitArtikel;

	@FXML
	private TableView<Artikel> vArtikel;

	@FXML
	private Button aAktuel;
	
	private ObservableList<Artikel> data;
	private FilteredList<Artikel> filteredData;
	
	
	
	
	
	@FXML
	void vArtikelClick(MouseEvent event) {
	if (vArtikel.getSelectionModel().getSelectedItem() == null) {
		event.consume();
		return;
	}
    
   
 //  ArtikelBearbeitenController artikelEdit = new ArtikelBearbeitenController (); 
 //  artikelEdit.setIdTitel(vArtikel.getSelectionModel().getSelectedItem().getTitel());

//   ArtikelBearbeitenController.setIdTitel(vArtikel.getSelectionModel().getSelectedItem().getTitel());
   
   
   	// Erstellt einen Dialogfenster
       Dialog<Artikel> dialog = new Dialog<>();
       dialog.setTitle("Bitte eine neue Menge einf�gen!");

       // Setzt die Buttonform/Art.
       ButtonType loginButtonType = new ButtonType("Speichern", ButtonData.OK_DONE);
       dialog.getDialogPane().getButtonTypes().addAll(loginButtonType, ButtonType.CANCEL);

       FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("ArtikelBearbeiten.fxml"));
       
       Parent p = null;
       
		try {
			p = fxmlLoader.load();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
       ArtikelBearbeitenController kbc = fxmlLoader.getController();
       kbc.setArtikel(vArtikel.getSelectionModel().getSelectedItem());

       dialog.getDialogPane().setContent(p);
      
           
       dialog.setResultConverter(dialogButton -> {
           if (dialogButton == loginButtonType) {
           	//liest die einzelnen Informationen aus den einzelnen textfeldern heraus
        	   return kbc.getArtikel();
           			
           }
           return null;
       });

       Optional<Artikel> result = dialog.showAndWait();

       result.ifPresent(artikel -> {
    	   		   try {
				ArtikelBean.updateArtikelBestand(artikel.getBestand(), artikel.getArtikelNr());
			} catch (SQLException e) {
				e.printStackTrace();
			}
    		   vArtikel.refresh();
    	   
       });
 

	}
	
	

	/**
	 * Methode vorbereitet TableView
	 */
	@FXML
	void initialize() {
		
		assert aAktuel != null : "fx:id=\"aAktuel\" was not injected: check your FXML file 'Artikel.fxml'.";
		assert suchfeldArtikel != null : "fx:id=\"suchfeldArtikel\" was not injected: check your FXML file 'Artikel.fxml'.";
		assert vArtikel != null : "fx:id=\"vArtikel\" was not injected: check your FXML file 'Artikel.fxml'.";
		
		initTable();
		suchfeldArtikel.textProperty().addListener((observable, oldValue, newValue)  -> sucheArtikel());
		
	}
	
	private void initTable() {
		// String autor, String titel, double preis, boolean status, int
				// bestand, int warengruppe

				

				// Spalten erstellen (�berschirften)
				TableColumn<Artikel, Integer> tc1 = new TableColumn<>("ANr");
				TableColumn<Artikel, String> tc2 = new TableColumn<>("Autor");
				TableColumn<Artikel, String> tc3 = new TableColumn<>("Titel");
				TableColumn<Artikel, Double> tc4 = new TableColumn<>("Preis");
				TableColumn<Artikel, Integer> tc5 = new TableColumn<>("Bestand");

				// Zuordnung Werte <-> Model
				tc1.setCellValueFactory(new PropertyValueFactory<>("artikelNr"));
				tc2.setCellValueFactory(new PropertyValueFactory<>("autor"));
				tc3.setCellValueFactory(new PropertyValueFactory<>("titel"));
				tc4.setCellValueFactory(new PropertyValueFactory<>("preis"));
				tc5.setCellValueFactory(new PropertyValueFactory<>("bestand"));

				// Spalten hinzuf�gen
				vArtikel.getColumns().add(tc1);
				vArtikel.getColumns().add(tc2);
				vArtikel.getColumns().add(tc3);
				vArtikel.getColumns().add(tc4);
				vArtikel.getColumns().add(tc5);

				try {
					data = ArtikelBean.getArtikelliste();
					
					filteredData = new FilteredList<>(data, p -> true);
					SortedList<Artikel> sortedData = new SortedList<>(filteredData);
					sortedData.comparatorProperty().bind(vArtikel.comparatorProperty());
					vArtikel.setItems(sortedData);
					
				} catch (SQLException e) {
					data = FXCollections.observableArrayList();
					vArtikel.setItems(data);
					e.printStackTrace();
				}
				
	}

	

	/**
	 * Methode sucht Artikel nach einem SuchWort
	 * 
	 * @param event
	 */
	
	void sucheArtikel() {
				
		filteredData.setPredicate((Artikel artikel) -> {
			boolean result = false;
			
			String gesuchtString = suchfeldArtikel.getText();
			if (gesuchtString.isEmpty()) {
				result = true;
			} else {
				result = result || artikel.getAutor().contains(gesuchtString);
				result = result || artikel.getTitel().contains(gesuchtString);
				result = result || Integer.toString(artikel.getArtikelNr()).contains(gesuchtString);
			}
			
			return result;
		});
	}

	/**
	 * Methode gibt eine Liste mit gefundenen Artikel zurueck
	 * 
	 * @param gesuchtString
	 * @return ObservableList<Artikel>
	 */
	/*public static ObservableList<Artikel> getSearchArtikelliste(String gesuchtString) {
		ObservableList<Artikel> result = FXCollections.observableArrayList();

		ArrayList<Artikel> alleArtikelListe = Artikelliste.getArtikelListe();
		String artikelTitel = "";
		String autor = "";
		String artikelNr = "";
		gesuchtString = gesuchtString.toLowerCase();

		for (Artikel artikel : alleArtikelListe) {
			artikelTitel = artikel.getTitel().toLowerCase();
			autor = artikel.getAutor().toLowerCase();
			artikelNr = Integer.toString(artikel.getArtikelNr()).toLowerCase();

			if ((artikelTitel.contains(gesuchtString)) || (autor.contains(gesuchtString))
					|| (artikelNr.contains(gesuchtString))) {
				result.add(artikel);
			}
		}
		return result;
	}*/

	/**
	 * Methode aktualisiert ArtikelListe
	 * 
	 * @param event
	 * @throws SQLException
	 */
	@FXML
	void artikelmenge_aktualisieren(ActionEvent event) throws SQLException {
		DBMethode dbArtikel = new DBMethode();
		dbArtikel.listeAktualisieren();
		try {
			data = ArtikelBean.getArtikelliste();
		} catch (SQLException e) {
			data = FXCollections.observableArrayList();
			e.printStackTrace();
		}
		vArtikel.setItems(data); // Daten ohne eigene Sortierung
		
	}

	



}
