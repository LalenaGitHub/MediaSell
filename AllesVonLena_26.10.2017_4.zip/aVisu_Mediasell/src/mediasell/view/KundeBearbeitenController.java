package mediasell.view;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import mediasell.model.Artikel;
import mediasell.model.Kunde;

public class KundeBearbeitenController {

	private Kunde kunde;

	@FXML
	private ResourceBundle resources;

	@FXML
	private URL location;

	@FXML
	private TextField tfVorname;

	@FXML
	private TextField tfNachname;

	@FXML
	private TextField tfStrasse;

	@FXML
	private TextField tfHausnummer;

	@FXML
	private TextField tfPlz;

	@FXML
	private TextField tfStadt;

	@FXML
	private TextField tfEmail;

	@FXML
	private TextField tfTelefonNr;

	@FXML
	private TextField tfStatus;

	@FXML
	private Button btnSperre;

	@FXML
	void initialize() {
		assert tfNachname != null : "fx:id=\"tfNachname\" was not injected: check your FXML file 'KundeBearbeiten.fxml'.";
		assert tfStrasse != null : "fx:id=\"tfStrasse\" was not injected: check your FXML file 'KundeBearbeiten.fxml'.";
		assert tfVorname != null : "fx:id=\"tfVorname\" was not injected: check your FXML file 'KundeBearbeiten.fxml'.";
		assert tfHausnummer != null : "fx:id=\"tfHausnummer\" was not injected: check your FXML file 'KundeBearbeiten.fxml'.";
		assert tfPlz != null : "fx:id=\"tfPlz\" was not injected: check your FXML file 'KundeBearbeiten.fxml'.";
		assert tfStadt != null : "fx:id=\"tfStadt\" was not injected: check your FXML file 'KundeBearbeiten.fxml'.";
		assert tfEmail != null : "fx:id=\"tfEmail\" was not injected: check your FXML file 'KundeBearbeiten.fxml'.";
		assert tfTelefonNr != null : "fx:id=\"tfTelefonNr\" was not injected: check your FXML file 'KundeBearbeiten.fxml'.";
		assert tfStatus != null : "fx:id=\"tfStatus\" was not injected: check your FXML file 'KundeBearbeiten.fxml'.";
		assert btnSperre != null : "fx:id=\"btnSperre\" was not injected: check your FXML file 'KundeBearbeiten.fxml'.";

	}

	String sperren = "Sperren";
	String entsperren = "Entsperren";

	@FXML
	void bSperren(ActionEvent event) {

		if (btnSperre.getText().equals(sperren)) {
			btnSperre.setText(entsperren);
			tfStatus.setText("Inaktiv");
		} else {
			btnSperre.setText(sperren);
			tfStatus.setText("Aktiv");
		}
	}

	public void setKunde(Kunde kunde) {
		if (kunde == null) {
			//
		} else {
			this.kunde = kunde;
			tfNachname.setText(kunde.getNachname());
			tfVorname.setText(kunde.getVorname());
			tfStrasse.setText(kunde.getStrasse());
			tfStadt.setText(kunde.getStadt());
			tfHausnummer.setText(kunde.getHausnr());
			tfPlz.setText(kunde.getPlz());
			tfEmail.setText(kunde.getEmail());
			tfTelefonNr.setText(kunde.getTelefonNr());

			if (kunde.isStatus()) {
				btnSperre.setText(sperren);
				tfStatus.setText("Aktiv");
			} else {
				tfStatus.setText("Inaktiv");
				btnSperre.setText(entsperren);
			}
		}

	}

	public Kunde getKunde() {
		kunde.setVorname(getTfVorname());
		kunde.setNachname(getTfNachname());
		kunde.setStadt(getTfStadt());
		kunde.setEmail(getTfEmail());
		kunde.setHausnr(getTfHausnummer());
		kunde.setPlz(getTfPlz());
		kunde.setStatus(getTfStatus());
		kunde.setStrasse(getTfStrasse());
		kunde.setTelefonNr(getTfTelefonNr());
		// kunde.setZahlungsart(zahlungsart);

		return kunde;
	}

	String getTfVorname() {
		return tfVorname.getText();
	}

	String getTfNachname() {
		return tfNachname.getText();
	}

	String getTfStrasse() {
		return tfStrasse.getText();
	}

	String getTfHausnummer() {
		return tfHausnummer.getText();
	}

	String getTfPlz() {
		return tfPlz.getText();
	}

	String getTfStadt() {
		return tfStadt.getText();
	}

	String getTfEmail() {
		return tfEmail.getText();
	}

	String getTfTelefonNr() {
		return tfTelefonNr.getText();
	}

	Boolean getTfStatus() {

		if (btnSperre.getText().equals(sperren)) {
			return true;
		} else {
			return false;
		}
	}
}
