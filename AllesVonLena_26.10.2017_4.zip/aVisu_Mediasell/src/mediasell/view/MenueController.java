package mediasell.view;

import java.io.IOException;

import java.util.Optional;


import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Tab;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.util.Pair;
import mediasell.datenbank.Datenbank;

public class MenueController {



	@FXML
	private Tab tabArtikel;

	@FXML
	private Tab tabKunde;

	@FXML
	private Tab tabKasse;

     
	@FXML
	void initialize() throws IOException {
		assert tabArtikel != null : "fx:id=\"tabArtikel\" was not injected: check your FXML file 'MenueGUI.fxml'.";
		assert tabKunde != null : "fx:id=\"tabKunde\" was not injected: check your FXML file 'MenueGUI.fxml'.";
		assert tabKasse != null : "fx:id=\"tabKasse\" was not injected: check your FXML file 'MenueGUI.fxml'.";

		AnchorPane apArtikelTab = FXMLLoader.load(getClass().getResource("Artikel.fxml"));
		AnchorPane apKundeTab = FXMLLoader.load(getClass().getResource("Kunde.fxml"));
		AnchorPane apKasselTab = FXMLLoader.load(getClass().getResource("Kassenvorgang.fxml"));

		tabArtikel.setContent(apArtikelTab);
		tabKunde.setContent(apKundeTab);
		tabKasse.setContent(apKasselTab);

		anmeldeFormular();
	}

	// ############### Login Button soll nur dann aktiviert werden wenn beide felder Benutzer und passwort ausgef�llt wurden
	public void anmeldeFormular() {
		// Create the custom dialog.
		Dialog<Pair<String, String>> dialog = new Dialog<>();
		dialog.setTitle("Anmeldung bei MediaSell");
		dialog.setHeaderText("Bitte melden Sie sich mit Ihrem Benutzernamen und Ihrem Passwort an!");

		// Set the button types.
		ButtonType loginButtonType = new ButtonType("Anmelden", ButtonData.OK_DONE);
		
	//	ButtonType abrechenButtonType = new ButtonType("Abrechen", ButtonData.CANCEL_CLOSE);
		
		dialog.getDialogPane().getButtonTypes().addAll(loginButtonType, ButtonType.CANCEL);

	//	dialog.getDialogPane().getButtonTypes().addAll(loginButtonType, abrechenButtonType);

		

		// Create the username and password labels and fields.
		GridPane grid = new GridPane();
		grid.setHgap(10);
		grid.setVgap(10);
		grid.setPadding(new Insets(20, 150, 10, 10));

		TextField benutzername = new TextField();
		benutzername.setPromptText("Benutzername");
		PasswordField passwort = new PasswordField();
		passwort.setPromptText("Passwort");

		grid.add(new Label("Benutzername:"), 0, 0);
		grid.add(benutzername, 1, 0);
		grid.add(new Label("Passwort:"), 0, 1);
		grid.add(passwort, 1, 1);

		// Enable/Disable login button depending on whether a username was
		// entered.
		Node anmeldeButton = dialog.getDialogPane().lookupButton(loginButtonType);
		anmeldeButton.setDisable(true);

		// Do some validation (using the Java 8 lambda syntax).
		benutzername.textProperty().addListener((observable, oldValue, newValue) -> {
			anmeldeButton.setDisable(newValue.trim().isEmpty());
		});

		dialog.getDialogPane().setContent(grid);

		// Setzt den Cursor in den Benutzerfeld ein
		Platform.runLater(() -> passwort.requestFocus());
        benutzername.setText("mediasell");
        passwort.setText("mediasell");
        
		// Convert the result to a username-password-pair when the login button
		// is clicked.
		dialog.setResultConverter(dialogButton -> {
			if (dialogButton == loginButtonType) {
				return new Pair<>(benutzername.getText(), passwort.getText());
			}
			else {
				Datenbank.getInstance().disconnect();
				System.exit(0);
			}
			return null;
		});

		
		
		
		
		
		//das mit result nochmal anschauen
		Optional<Pair<String, String>> result = dialog.showAndWait();
		
		if (result == null) {
			
			Datenbank.getInstance().disconnect();
			System.exit(0);
			
		} else {
			result.ifPresent(benutzernamePasswort -> {
				System.out.println("Benutzername=" + benutzernamePasswort.getKey() + ", Passwort="
						+ benutzernamePasswort.getValue());
			});

			// �berpr�ft die Passworteingabe
			if (benutzername.getText().equals("mediasell")  && passwort.getText().equals("mediasell"))	{
			//	anmeldeButton.setDisable(false); // aktiviert den Ameldebutton	
			} else {
				 fehlermeldungAusgeben();
			}
		}
	}

	public void fehlermeldungAusgeben() {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Falscher Benutzer");
		alert.setHeaderText(null);
		alert.setContentText("Der eingebene Benutzername oder das Passwort ist falsch!");
		
		alert.showAndWait();
		anmeldeFormular(); // Nach der Anmeldung mit falschen Daten wird das
							// Anmeldeformular erneut aufgerufen
	}
}
