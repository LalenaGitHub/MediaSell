package mediasell.view;


import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import mediasell.model.Artikel;

public class ArtikelBearbeitenController {
	
	private Artikel artikel;
  

    @FXML
    private TextField tf_Autor;

    @FXML
    private  TextField tf_Titel;

    @FXML
    private TextField tf_ArtikelNr;

    @FXML
    private TextField tf_Preis;

    @FXML
    private TextField tf_Bestand;

    @FXML
    void initialize() {
        assert tf_Autor != null : "fx:id=\"idAutor\" was not injected: check your FXML file 'ArtikelBearbeiten.fxml'.";
        assert tf_Titel != null : "fx:id=\"idTitel\" was not injected: check your FXML file 'ArtikelBearbeiten.fxml'.";
        assert tf_ArtikelNr != null : "fx:id=\"idArtikelNr\" was not injected: check your FXML file 'ArtikelBearbeiten.fxml'.";
        assert tf_Preis != null : "fx:id=\"idPreis\" was not injected: check your FXML file 'ArtikelBearbeiten.fxml'.";
        assert tf_Bestand != null : "fx:id=\"idBestand\" was not injected: check your FXML file 'ArtikelBearbeiten.fxml'.";

        
        tf_Autor.setDisable(true);
    	tf_Titel.setDisable(true);
    	tf_ArtikelNr.setDisable(true);
    	tf_Preis.setDisable(true);
    	
    	
    }
    
    public void setArtikel(Artikel artikel) {
		this.artikel = artikel;
		tf_Autor.setText(artikel.getAutor());
    	tf_Titel.setText(artikel.getTitel());
    	tf_ArtikelNr.setText(Integer.toString(artikel.getArtikelNr()));
    	tf_Preis.setText(Double.toString(artikel.getPreis()));
		tf_Bestand.setText(Integer.toString(artikel.getBestand()));
	}

	public Artikel getArtikel() {
		artikel.setBestand(Integer.parseInt(tf_Bestand.getText()));
		return artikel;
	}



 
}
